# HBMS – Hotel & Hostel Management System
### Complete PHP + MySQL Web Application

---

## ⚡ QUICK SETUP (3 Steps)

### Step 1 — Copy Files
Copy the `hbms/` folder into your web server root:
- **XAMPP (Windows):** `C:/xampp/htdocs/hbms/`
- **WAMP:**           `C:/wamp64/www/hbms/`
- **Laragon:**        `C:/laragon/www/hbms/`
- **Linux Apache:**   `/var/www/html/hbms/`

### Step 2 — Create the Database
1. Open **phpMyAdmin** → `http://localhost/phpmyadmin`
2. Click **"Import"** tab at the top
3. Choose file: `hbms/includes/database.sql`
4. Click **"Go"** — this creates the database, all tables and sample data

### Step 3 — Configure & Run
1. Open `hbms/includes/config.php`
2. Update if needed:
   ```php
   define('DB_HOST', 'localhost');
   define('DB_USER', 'root');       // your MySQL username
   define('DB_PASS', '');           // your MySQL password (blank for XAMPP default)
   define('DB_NAME', 'hbms_db');
   define('BASE_URL', 'http://localhost/hbms/');
   ```
3. Open browser: **`http://localhost/hbms/`**

---

## 🔐 Login Credentials

| Role    | Email               | Password    | Redirect              |
|---------|---------------------|-------------|------------------------|
| Admin   | admin@hbms.com      | password    | `/pages/admin/dashboard.php` |
| Staff   | staff@hbms.com      | password    | `/pages/admin/dashboard.php` |
| Guest   | guest@hbms.com      | password    | `/pages/dashboard.php` |

> You can register new guest accounts from the Register page.

---

## 📁 Project Structure

```
hbms/
├── index.php                     ← Homepage
├── css/
│   └── style.css                 ← Complete stylesheet (all pages)
├── js/
│   └── main.js                   ← Slider, counters, gallery, booking JS
├── includes/
│   ├── config.php                ← DB connection + helper functions
│   ├── layout.php                ← Public header/footer templates
│   ├── admin_layout.php          ← Admin sidebar/header template
│   └── database.sql              ← Full DB schema + seed data
├── php/
│   └── auth.php                  ← Login / Register / Logout handler
└── pages/
    ├── login.php                 ← Sign In page
    ├── register.php              ← Register page
    ├── dashboard.php             ← Guest dashboard (bookings, stats)
    ├── rooms.php                 ← Rooms listing with live DB filter
    ├── booking.php               ← 4-step booking wizard → saves to DB
    ├── contact.php               ← Contact form → saves to DB
    ├── about.php                 ← About page
    ├── facilities.php            ← Facilities listing
    ├── gallery.php               ← Photo gallery with lightbox
    └── admin/
        ├── dashboard.php         ← Admin stats overview
        ├── bookings.php          ← Manage all bookings + status updates
        ├── rooms.php             ← Add/edit/delete rooms
        ├── guests.php            ← View/activate/deactivate guests
        ├── messages.php          ← Inbox for contact messages
        └── settings.php          ← Admin profile + system info
```

---

## ✨ Features

### Public Site
- Auto-playing hero slider with 3 slides
- Quick search/booking bar on homepage (passes to rooms page)
- Services, featured rooms, animated stats counters
- Testimonials carousel with DB reviews
- Masonry photo gallery with filter tabs and lightbox
- Facilities grid with photos and opening hours
- About page with team, mission/vision, awards
- Contact form — saves to database

### Guest Account
- Register and login with session management
- Dashboard showing booking history, stats
- Book rooms via 4-step wizard (dates → details → payment → confirm)
- Cancel pending bookings
- Role-based redirect on login

### Admin Panel
- Dashboard with live stats (rooms, bookings, revenue, guests)
- Manage all bookings — update status and payment inline
- Room manager — add rooms, change status, delete
- Guest list with search, pagination, activate/deactivate
- Message inbox — read, reply, delete contact messages
- Settings — update admin profile and password

---

## 🗄️ Database Tables

| Table               | Purpose                          |
|---------------------|----------------------------------|
| `users`             | All accounts + roles             |
| `room_types`        | Room categories + pricing        |
| `rooms`             | Individual room records          |
| `bookings`          | All reservations                 |
| `contact_messages`  | Contact form submissions         |
| `reviews`           | Guest reviews (approved flag)    |

---

## 🎨 Design Details
- **Fonts:** Playfair Display (headings) + Jost (body)
- **Colors:** Green `#27ae60`, Dark `#1a1a2e`, Gold `#c8a84b`
- **Fully responsive** – works on mobile, tablet and desktop
- All pages use PHP — data is live from MySQL database

---

*HBMS © 2025 — Built with PHP, MySQL, HTML5, CSS3, JavaScript*
