/* HBMS – main.js */

// Navbar scroll
const nb = document.getElementById('navbar');
if(nb) window.addEventListener('scroll',()=>nb.classList.toggle('scrolled',window.scrollY>60));

// Hamburger
const hb = document.getElementById('hamburger');
const nl = document.getElementById('navLinks');
if(hb) hb.addEventListener('click',()=>nl.classList.toggle('open'));

// Hero slider
let cs=0;
const slides=document.querySelectorAll('.slide');
const dots=document.querySelectorAll('.dot');
function goSlide(n){
  if(!slides.length)return;
  slides[cs].classList.remove('active');
  if(dots[cs])dots[cs].classList.remove('active');
  cs=(n+slides.length)%slides.length;
  slides[cs].classList.add('active');
  if(dots[cs])dots[cs].classList.add('active');
}
window.goSlide=goSlide;
if(slides.length)setInterval(()=>goSlide(cs+1),5000);

// Testimonials
let ti=0;
const testis=document.querySelectorAll('.testimonial');
function showT(n){if(!testis.length)return;testis[ti].classList.remove('active');ti=(n+testis.length)%testis.length;testis[ti].classList.add('active');}
window.nextTesti=()=>showT(ti+1);
window.prevTesti=()=>showT(ti-1);
if(testis.length)setInterval(()=>showT(ti+1),6000);

// Counters
function animCounter(el){
  const t=+el.dataset.target; let c=0;
  const step=Math.max(1,t/80);
  const iv=setInterval(()=>{c=Math.min(c+step,t);el.textContent=Math.floor(c).toLocaleString();if(c>=t)clearInterval(iv);},20);
}
const obs=new IntersectionObserver(entries=>{
  entries.forEach(e=>{
    if(e.isIntersecting){
      e.target.classList.add('aos-animate');
      if(e.target.classList.contains('counter'))animCounter(e.target);
      obs.unobserve(e.target);
    }
  });
},{threshold:.15});
document.querySelectorAll('[data-aos],.counter').forEach(el=>{
  if(!el.classList.contains('aos-animate'))obs.observe(el);
});

// Auto dismiss flash
const fl=document.querySelector('.flash');
if(fl)setTimeout(()=>fl.style.opacity='0',4000);

// Default booking dates
function setDefaultDates(){
  const today=new Date().toISOString().split('T')[0];
  const tmrw=new Date(Date.now()+86400000).toISOString().split('T')[0];
  const ci=document.getElementById('checkIn');
  const co=document.getElementById('checkOut');
  if(ci){ci.min=today;if(!ci.value)ci.value=today;}
  if(co){co.min=tmrw;if(!co.value)co.value=tmrw;}
}
setDefaultDates();
