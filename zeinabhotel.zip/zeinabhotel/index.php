<?php
require_once __DIR__.'/includes/config.php';
require_once __DIR__.'/includes/layout.php';

// Fetch featured rooms from DB
$roomsStmt = $pdo->query("SELECT rt.*, r.room_number, r.id AS room_id FROM room_types rt JOIN rooms r ON r.type_id=rt.id WHERE r.status='available' GROUP BY rt.id LIMIT 3");
$featRooms  = $roomsStmt->fetchAll();

// Fetch approved reviews
$reviews = $pdo->query("SELECT rv.*, u.name FROM reviews rv JOIN users u ON rv.user_id=u.id WHERE rv.approved=1 ORDER BY rv.created_at DESC LIMIT 3")->fetchAll();

include_header('Home', 'home');
?>
<!-- HERO -->
<section class="hero">
  <div class="hero-overlay"></div>
  <div class="hero-slides">
    <div class="slide slide-1 active"></div>
    <div class="slide slide-2"></div>
    <div class="slide slide-3"></div>
  </div>
  <div class="hero-content">
    <p class="hero-sub">Welcome to HBMS</p>
    <h1 class="hero-title">Great Choice Of <span>Hotels</span></h1>
    <p class="hero-desc">Experience luxury redefined. Book your perfect stay with seamless management.</p>
    <div class="hero-btns">
      <a href="<?=BASE_URL?>pages/rooms.php" class="btn-primary">Explore Rooms</a>
      <a href="<?=BASE_URL?>pages/booking.php" class="btn-secondary">Book Now</a>
    </div>
  </div>
  <div class="hero-dots">
    <span class="dot active" onclick="goSlide(0)"></span>
    <span class="dot" onclick="goSlide(1)"></span>
    <span class="dot" onclick="goSlide(2)"></span>
  </div>
</section>

<!-- QUICK BOOKING BAR -->
<section class="booking-bar">
  <form class="booking-inner" action="<?=BASE_URL?>pages/rooms.php" method="GET">
    <div class="booking-field">
      <label><i class="fas fa-calendar-check"></i> Check In</label>
      <input type="date" name="checkin" id="checkIn"/>
    </div>
    <div class="booking-field">
      <label><i class="fas fa-calendar-times"></i> Check Out</label>
      <input type="date" name="checkout" id="checkOut"/>
    </div>
    <div class="booking-field">
      <label><i class="fas fa-users"></i> Guests</label>
      <select name="guests">
        <option>1 Guest</option><option selected>2 Guests</option>
        <option>3 Guests</option><option>4+ Guests</option>
      </select>
    </div>
    <div class="booking-field">
      <label><i class="fas fa-bed"></i> Room Type</label>
      <select name="type">
        <option value="">Any Type</option>
        <option>Standard Room</option><option>Deluxe Room</option>
        <option>Executive Suite</option><option>Dormitory Bed</option>
      </select>
    </div>
    <button type="submit" class="btn-search"><i class="fas fa-search"></i> Search</button>
  </form>
</section>

<!-- SERVICES -->
<section class="services">
  <div class="container">
    <div class="section-header">
      <p class="section-tag">What We Offer</p>
      <h2 class="section-title">Our <span>Services</span></h2>
      <div class="divider"></div>
    </div>
    <div class="services-grid">
      <div class="service-card" data-aos>
        <div class="service-icon" style="background:#27ae60"><i class="fas fa-map-marked-alt"></i></div>
        <h3>Tour &amp; Excursions</h3>
        <p>Guided city tours and excursions available every day, making your stay truly memorable.</p>
        <a href="<?=BASE_URL?>pages/facilities.php" class="read-more">Read More <i class="fas fa-arrow-right"></i></a>
      </div>
      <div class="service-card" data-aos>
        <div class="service-icon" style="background:#2980b9"><i class="fas fa-wifi"></i></div>
        <h3>Free Wireless Internet</h3>
        <p>Stay connected with high-speed fibre Wi-Fi available throughout the entire property at no charge.</p>
        <a href="<?=BASE_URL?>pages/facilities.php" class="read-more">Read More <i class="fas fa-arrow-right"></i></a>
      </div>
      <div class="service-card" data-aos>
        <div class="service-icon" style="background:#e67e22"><i class="fas fa-concierge-bell"></i></div>
        <h3>Babysitting On Request</h3>
        <p>Professional babysitting available on request so parents can relax with complete peace of mind.</p>
        <a href="<?=BASE_URL?>pages/facilities.php" class="read-more">Read More <i class="fas fa-arrow-right"></i></a>
      </div>
      <div class="service-card" data-aos>
        <div class="service-icon" style="background:#8e44ad"><i class="fas fa-soap"></i></div>
        <h3>Laundry Service</h3>
        <p>Full laundry with same-day express turnaround, keeping you fresh for every occasion.</p>
        <a href="<?=BASE_URL?>pages/facilities.php" class="read-more">Read More <i class="fas fa-arrow-right"></i></a>
      </div>
    </div>
  </div>
</section>

<!-- FEATURED ROOMS -->
<section class="featured-rooms">
  <div class="container">
    <div class="section-header">
      <p class="section-tag">Comfort &amp; Luxury</p>
      <h2 class="section-title">Featured <span>Rooms</span></h2>
      <div class="divider"></div>
    </div>
    <div class="rooms-grid">
      <?php if(empty($featRooms)):
        $featRooms = [
          ['room_id'=>1,'name'=>'Standard Room','price'=>89,'capacity'=>2,'size_sqm'=>25,'image_url'=>'https://images.unsplash.com/photo-1631049307264-da0ec9d70304?w=800','amenities'=>'WiFi,AC,TV'],
          ['room_id'=>3,'name'=>'Executive Suite','price'=>249,'capacity'=>4,'size_sqm'=>60,'image_url'=>'https://images.unsplash.com/photo-1611892440504-42a792e24d32?w=800','amenities'=>'WiFi,AC,TV,Jacuzzi'],
          ['room_id'=>5,'name'=>'Dormitory Bed','price'=>25,'capacity'=>1,'size_sqm'=>8,'image_url'=>'https://images.unsplash.com/photo-1590490360182-c33d57733427?w=800','amenities'=>'WiFi,Locker'],
        ];
      endif;
      foreach($featRooms as $i=>$r):
        $badge = $i===1 ? '<div class="room-badge popular">Popular</div>' : ($r['name']==='Dormitory Bed' ? '<div class="room-badge dorm">Dorm</div>' : '<div class="room-badge">'.e($r['name']).'</div>');
        $amenArr = explode(',', $r['amenities']??'');
      ?>
      <div class="room-card <?=$i===1?'featured':''?>" data-aos>
        <div class="room-img" style="background:url('<?=e($r['image_url'])?>') center/cover"></div>
        <?=$badge?>
        <div class="room-info">
          <h3><?=e($r['name'])?></h3>
          <div class="room-meta">
            <span><i class="fas fa-users"></i> <?=$r['capacity']?> Guests</span>
            <span><i class="fas fa-expand"></i> <?=$r['size_sqm']?>m²</span>
            <span><i class="fas fa-tag"></i> <?=implode(', ',array_slice($amenArr,0,2))?></span>
          </div>
          <div class="room-footer">
            <span class="price"><?=fmtCur($r['price'])?><sub>/night</sub></span>
            <a href="<?=BASE_URL?>pages/booking.php?room_id=<?=$r['room_id']?>" class="btn-book">Book Now</a>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
    <div style="text-align:center;margin-top:2.5rem">
      <a href="<?=BASE_URL?>pages/rooms.php" class="btn-primary">View All Rooms</a>
    </div>
  </div>
</section>

<!-- STATS -->
<section class="stats-section">
  <div class="stats-overlay"></div>
  <div class="container stats-grid">
    <div class="stat-item"><i class="fas fa-hotel"></i><h3 class="counter" data-target="120">0</h3><p>Rooms Available</p></div>
    <div class="stat-item"><i class="fas fa-smile"></i><h3 class="counter" data-target="4500">0</h3><p>Happy Guests</p></div>
    <div class="stat-item"><i class="fas fa-star"></i><h3 class="counter" data-target="15">0</h3><p>Years Experience</p></div>
    <div class="stat-item"><i class="fas fa-award"></i><h3 class="counter" data-target="28">0</h3><p>Awards Won</p></div>
  </div>
</section>

<!-- TESTIMONIALS -->
<section class="testimonials">
  <div class="container">
    <div class="section-header">
      <p class="section-tag">Guest Reviews</p>
      <h2 class="section-title">What Guests <span>Say</span></h2>
      <div class="divider"></div>
    </div>
    <div class="testi-slider">
      <?php
      $defaults=[
        ['name'=>'James Donovan','role'=>'Business Traveler','rating'=>5,'comment'=>'Absolutely wonderful experience. The staff was attentive, rooms spotless. Will definitely return!'],
        ['name'=>'Abena Osei',   'role'=>'Solo Traveler',    'rating'=>5,'comment'=>'The online booking was seamless. Everything was ready when I arrived. Truly a first-class experience.'],
        ['name'=>'Michael Kofi', 'role'=>'Backpacker',       'rating'=>4,'comment'=>'Great facilities, clean dormitories and very friendly staff. The Wi-Fi was fast and breakfast excellent.'],
      ];
      $testimonials = !empty($reviews) ? $reviews : $defaults;
      foreach($testimonials as $idx=>$t):
        $stars=str_repeat('★',min(5,(int)($t['rating']??5)));
        $comment = isset($t['comment']) ? $t['comment'] : ($t['comment']??'');
        $name    = $t['name']??'Guest';
        $role    = $t['role']??'Guest';
        $init    = strtoupper(substr($name,0,2));
      ?>
      <div class="testimonial <?=$idx===0?'active':''?>">
        <div class="stars"><?=$stars?></div>
        <p>"<?=e($comment)?>"</p>
        <div class="t-author">
          <div class="t-avatar"><?=$init?></div>
          <div><strong><?=e($name)?></strong><br/><small style="color:#888"><?=e($role)?></small></div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
    <div class="t-controls">
      <button onclick="prevTesti()"><i class="fas fa-chevron-left"></i></button>
      <button onclick="nextTesti()"><i class="fas fa-chevron-right"></i></button>
    </div>
  </div>
</section>

<!-- CONTACT PREVIEW -->
<section class="contact-preview">
  <div class="container">
    <div class="section-header" style="margin-bottom:2.5rem">
      <p class="section-tag" style="color:#c8a84b">Get In Touch</p>
      <h2 class="section-title" style="color:#fff">Contact <span>Us</span></h2>
      <div class="divider"></div>
    </div>
    <div class="contact-grid">
      <div class="contact-info-box">
        <h3><i class="fas fa-map-marker-alt"></i> Address</h3>
        <p>21 Liberty Street, Ring Road Central<br/>Accra, Greater Accra, Ghana</p>
      </div>
      <div class="contact-info-box">
        <h3><i class="fas fa-phone-alt"></i> Phone &amp; Email</h3>
        <p>+233 30 222 5555<br/>+233 24 000 1234<br/>info@hbms.com</p>
      </div>
      <div class="contact-info-box">
        <h3><i class="fas fa-info-circle"></i> About HBMS</h3>
        <p>HBMS is a certified hospitality leader in accommodation, tourism, and hostel management — delivering world-class guest experiences every day.</p>
      </div>
    </div>
  </div>
</section>

<?php include_footer(); ?>
