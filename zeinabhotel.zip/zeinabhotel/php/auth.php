<?php
require_once __DIR__.'/../includes/config.php';

$action = $_REQUEST['action'] ?? '';

switch ($action) {

    // ── REGISTER ──────────────────────────────────────────────
    case 'register':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') redirect(BASE_URL.'pages/register.php');

        $name    = sanitize($_POST['name']    ?? '');
        $email   = sanitize($_POST['email']   ?? '');
        $phone   = sanitize($_POST['phone']   ?? '');
        $pass    = $_POST['password'] ?? '';
        $confirm = $_POST['confirm']  ?? '';

        if (!$name || !$email || !$pass) { flash('error','All fields are required.'); redirect(BASE_URL.'pages/register.php'); }
        if (!filter_var($email,FILTER_VALIDATE_EMAIL)) { flash('error','Invalid email address.'); redirect(BASE_URL.'pages/register.php'); }
        if (strlen($pass) < 6) { flash('error','Password must be at least 6 characters.'); redirect(BASE_URL.'pages/register.php'); }
        if ($pass !== $confirm) { flash('error','Passwords do not match.'); redirect(BASE_URL.'pages/register.php'); }

        $exists = $pdo->prepare("SELECT id FROM users WHERE email=?");
        $exists->execute([$email]);
        if ($exists->fetch()) { flash('error','Email already registered. Please sign in.'); redirect(BASE_URL.'pages/login.php'); }

        $hash = password_hash($pass, PASSWORD_BCRYPT);
        $stmt = $pdo->prepare("INSERT INTO users (name,email,phone,password,role) VALUES (?,?,?,?,'guest')");
        $stmt->execute([$name, $email, $phone, $hash]);
        $id = $pdo->lastInsertId();

        $_SESSION['user_id']   = $id;
        $_SESSION['user_name'] = $name;
        $_SESSION['role']      = 'guest';

        flash('success', "Welcome, $name! Your account has been created.");
        redirect(BASE_URL.'pages/dashboard.php');
        break;

    // ── LOGIN ─────────────────────────────────────────────────
    case 'login':
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') redirect(BASE_URL.'pages/login.php');

        $email = sanitize($_POST['email']    ?? '');
        $pass  = $_POST['password'] ?? '';

        if (!$email || !$pass) { flash('error','Email and password are required.'); redirect(BASE_URL.'pages/login.php'); }

        $stmt = $pdo->prepare("SELECT * FROM users WHERE email=? AND status='active'");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if (!$user || !password_verify($pass, $user['password'])) {
            flash('error','Invalid email or password. Please try again.');
            redirect(BASE_URL.'pages/login.php');
        }

        $_SESSION['user_id']   = $user['id'];
        $_SESSION['user_name'] = $user['name'];
        $_SESSION['role']      = $user['role'];

        flash('success', "Welcome back, {$user['name']}!");

        // Redirect based on role
        if (in_array($user['role'], ['admin','staff'])) {
            redirect(BASE_URL.'pages/admin/dashboard.php');
        } else {
            // Go to intended page if set
            $intended = $_SESSION['intended'] ?? '';
            unset($_SESSION['intended']);
            redirect($intended ?: BASE_URL.'pages/dashboard.php');
        }
        break;

    // ── LOGOUT ───────────────────────────────────────────────
    case 'logout':
        session_destroy();
        redirect(BASE_URL.'pages/login.php');
        break;

    default:
        redirect(BASE_URL.'index.php');
}
