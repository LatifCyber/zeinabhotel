<?php
require_once __DIR__.'/../includes/config.php';
require_once __DIR__.'/../includes/layout.php';
include_header('About Us','about');
?>
<section class="page-hero" style="background:url('https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?w=1400')center/cover;padding-top:70px">
  <div class="page-hero-content"><h1>About HBMS</h1><p class="breadcrumb"><a href="<?=BASE_URL?>index.php">Home</a> / <span>About</span></p></div>
</section>

<section style="padding:5rem 0;background:#fff">
  <div class="container">
    <div class="about-grid">
      <div class="about-img-wrap">
        <img src="https://images.unsplash.com/photo-1566073771259-6a8506099945?w=700" alt="HBMS" class="about-img-main"/>
        <div class="exp-badge"><b>15+</b><small>YEARS</small></div>
      </div>
      <div>
        <p class="section-tag">Who We Are</p>
        <h2 class="section-title">A Legacy of <span>Hospitality</span></h2>
        <div class="divider" style="margin:1rem 0"></div>
        <p style="color:#666;line-height:1.9;margin-bottom:1rem">HBMS was founded with a singular vision: to create a place where every guest feels genuinely at home, whether they're a business traveler, a family on holiday, or a backpacker exploring the world.</p>
        <p style="color:#666;line-height:1.9;margin-bottom:1rem">Over 15 years we've grown from a single boutique hostel into a full-scale hotel management system serving thousands of guests annually. Our commitment to quality and warmth has earned us recognition across the hospitality industry.</p>
        <div class="about-feats">
          <?php foreach(['24/7 Guest Support','Verified Clean Rooms','Flexible Bookings','Award-Winning Service','Secure Online Payments','Multi-Language Staff'] as $f): ?>
          <div class="afeat"><i class="fas fa-check-circle"></i> <?=$f?></div>
          <?php endforeach; ?>
        </div>
        <a href="<?=BASE_URL?>pages/rooms.php" class="btn-primary" style="margin-top:1.5rem;display:inline-block">Explore Rooms</a>
      </div>
    </div>
  </div>
</section>

<section style="padding:5rem 0;background:#f7f9f7">
  <div class="container">
    <div class="section-header"><p class="section-tag">Our Foundation</p><h2 class="section-title">Mission, Vision &amp; <span>Values</span></h2><div class="divider"></div></div>
    <div class="mv-grid" style="margin-top:3rem">
      <?php foreach([
        ['fa-bullseye','Our Mission','To provide every guest with exceptional comfort, seamless service, and memorable experiences regardless of their budget.'],
        ['fa-eye',      'Our Vision', 'To become the leading hospitality brand in West Africa, recognized for innovation and unwavering excellence.'],
        ['fa-heart',    'Our Values', 'Integrity in every interaction, warmth in every welcome, and sustainability in every decision we make.'],
      ] as [$ic,$title,$text]): ?>
      <div class="mv-card" data-aos>
        <div class="mv-icon"><i class="fas <?=$ic?>"></i></div>
        <h3><?=$title?></h3>
        <p><?=$text?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<section style="padding:5rem 0;background:#fff">
  <div class="container">
    <div class="section-header"><p class="section-tag">The People Behind HBMS</p><h2 class="section-title">Meet Our <span>Team</span></h2><div class="divider"></div></div>
    <div class="team-grid" style="margin-top:3rem">
      <?php $team=[
        ['James Mensah','Chief Executive Officer','https://images.unsplash.com/photo-1560250097-0b93528c311a?w=300'],
        ['Abena Osei',  'General Manager',        'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=300'],
        ['Kofi Agyemang','Head of Operations',    'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300'],
        ['Akosua Darko','Guest Relations Lead',   'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=300'],
      ];
      foreach($team as $m): ?>
      <div class="team-card" data-aos>
        <div class="team-img"><img src="<?=$m[2]?>" alt="<?=$m[0]?>"/></div>
        <h4><?=$m[0]?></h4>
        <div class="role"><?=$m[1]?></div>
        <div style="display:flex;justify-content:center;gap:.4rem">
          <?php foreach(['fab fa-linkedin-in','fab fa-twitter','fas fa-envelope'] as $ic): ?>
          <a href="#" style="width:28px;height:28px;border-radius:50%;border:1px solid #e0e0e0;display:flex;align-items:center;justify-content:center;color:#888;font-size:.72rem;transition:all .3s" onmouseover="this.style.background='#27ae60';this.style.color='#fff';this.style.borderColor='#27ae60'" onmouseout="this.style.background='';this.style.color='#888';this.style.borderColor='#e0e0e0'"><i class="<?=$ic?>"></i></a>
          <?php endforeach; ?>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php include_footer(); ?>
