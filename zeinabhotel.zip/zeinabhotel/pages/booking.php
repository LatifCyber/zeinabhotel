<?php
require_once __DIR__.'/../includes/config.php';
require_once __DIR__.'/../includes/layout.php';

// Handle booking submission
if ($_SERVER['REQUEST_METHOD']==='POST') {
    requireLogin();
    $roomId   = (int)$_POST['room_id'];
    $checkIn  = sanitize($_POST['check_in']);
    $checkOut = sanitize($_POST['check_out']);
    $guestCnt = (int)$_POST['guests'];
    $special  = sanitize($_POST['special_requests']??'');
    $payMethod= sanitize($_POST['payment_method']??'card');

    // Validate
    if (!$roomId || !$checkIn || !$checkOut) { flash('error','Please fill all required fields.'); redirect(BASE_URL.'pages/booking.php'); }
    $n = nights($checkIn,$checkOut);
    if ($n < 1) { flash('error','Check-out must be after check-in.'); redirect(BASE_URL.'pages/booking.php?room_id='.$roomId); }

    // Get room + price
    $stmt = $pdo->prepare("SELECT r.*, rt.price, rt.name AS type_name, rt.capacity FROM rooms r JOIN room_types rt ON r.type_id=rt.id WHERE r.id=? AND r.status='available'");
    $stmt->execute([$roomId]);
    $room = $stmt->fetch();
    if (!$room) { flash('error','Room not available.'); redirect(BASE_URL.'pages/rooms.php'); }

    // Check overlapping bookings
    $overlap = $pdo->prepare("SELECT id FROM bookings WHERE room_id=? AND status NOT IN('cancelled','checked_out') AND check_in<? AND check_out>?");
    $overlap->execute([$roomId,$checkOut,$checkIn]);
    if ($overlap->fetch()) { flash('error','Room already booked for those dates. Please choose different dates.'); redirect(BASE_URL.'pages/rooms.php'); }

    $subtotal = $room['price'] * $n;
    $tax      = $subtotal * 0.10;
    $total    = $subtotal + $tax;
    $ref      = bookingRef();

    $ins = $pdo->prepare("INSERT INTO bookings (booking_ref,user_id,room_id,check_in,check_out,guests,total_amount,payment_method,special_requests) VALUES (?,?,?,?,?,?,?,?,?)");
    $ins->execute([$ref, $_SESSION['user_id'], $roomId, $checkIn, $checkOut, $guestCnt, $total, $payMethod, $special]);

    // ── Redirect to receipt page instead of dashboard ──
    redirect(BASE_URL.'pages/receipt.php?ref='.urlencode($ref).'&new=1');
}

// Pre-fill from URL params
$roomId   = (int)($_GET['room_id'] ?? 0);
$checkin  = sanitize($_GET['checkin']  ?? date('Y-m-d'));
$checkout = sanitize($_GET['checkout'] ?? date('Y-m-d', strtotime('+1 day')));

// Fetch room types for picker
$roomTypes = $pdo->query("SELECT rt.*, r.id AS room_id FROM room_types rt JOIN rooms r ON r.type_id=rt.id WHERE r.status='available' GROUP BY rt.id ORDER BY rt.price")->fetchAll();

// Selected room
$selectedRoom = null;
if ($roomId) {
    $s = $pdo->prepare("SELECT r.*, rt.name AS type_name, rt.price, rt.capacity, rt.amenities, rt.image_url FROM rooms r JOIN room_types rt ON r.type_id=rt.id WHERE r.id=?");
    $s->execute([$roomId]); $selectedRoom = $s->fetch();
}
if (!$selectedRoom && !empty($roomTypes)) {
    $rt = $roomTypes[0];
    $selectedRoom = ['id'=>$rt['room_id'],'room_number'=>'TBD','type_name'=>$rt['name'],'price'=>$rt['price'],'capacity'=>$rt['capacity'],'amenities'=>$rt['amenities'],'image_url'=>$rt['image_url']];
    $roomId = $rt['room_id'];
}

$flash = getFlash();
include_header('Book a Room', 'rooms');
?>
<section class="page-hero" style="background:url('https://images.unsplash.com/photo-1618773928121-c32242e63f39?w=1400')center/cover;height:260px;padding-top:70px">
  <div class="page-hero-content">
    <h1>Book Your Stay</h1>
    <p class="breadcrumb"><a href="<?=BASE_URL?>index.php">Home</a> / <a href="<?=BASE_URL?>pages/rooms.php">Rooms</a> / <span>Book</span></p>
  </div>
</section>

<section style="padding:4rem 0;background:#f7f9f7">
  <div class="container">
    <?php if($flash): ?>
    <div class="d-flash <?=$flash['type']?>" style="margin-bottom:1.5rem"><?=$flash['msg']?></div>
    <?php endif; ?>

    <div class="booking-layout">
      <!-- FORM -->
      <div class="bform-card">
        <!-- STEPS -->
        <div class="steps-bar">
          <div class="sdot active" id="sd1"><div class="snum">1</div><span>Room &amp; Dates</span></div>
          <div class="sdot" id="sd2"><div class="snum">2</div><span>Your Details</span></div>
          <div class="sdot" id="sd3"><div class="snum">3</div><span>Payment</span></div>
          <div class="sdot" id="sd4"><div class="snum">4</div><span>Confirm</span></div>
        </div>

        <form method="POST" action="<?=BASE_URL?>pages/booking.php" id="bForm">
          <input type="hidden" name="room_id" id="roomIdInput" value="<?=$roomId?>"/>

          <!-- STEP 1 -->
          <div class="form-step active" id="step1">
            <h3 style="font-family:'Playfair Display',serif;font-size:1.4rem;color:#1a1a2e;margin-bottom:.4rem">Select Room &amp; Dates</h3>
            <p style="color:#888;font-size:.88rem;margin-bottom:1.4rem">Choose your preferred room type and stay period.</p>

            <div class="fg">
              <label>Room Type</label>
              <div class="room-picker">
                <?php foreach($roomTypes as $rt): ?>
                <label class="ropt <?=$rt['room_id']==$roomId?'sel':''?>" onclick="selectRoom(this,<?=$rt['room_id']?>,'<?=addslashes($rt['name'])?>',<?=$rt['price']?>,'<?=addslashes($rt['image_url'])?>')">
                  <i class="fas fa-<?=$rt['name']==='Dormitory Bed'?'users':($rt['name']==='Executive Suite'?'crown':($rt['name']==='Family Room'?'home':'bed'))?>"></i>
                  <strong><?=e($rt['name'])?></strong>
                  <span><?=fmtCur($rt['price'])?>/night</span>
                </label>
                <?php endforeach; ?>
              </div>
            </div>
            <div class="form-row-2" style="gap:1rem">
              <div class="fg">
                <label>Check-In Date *</label>
                <input type="date" name="check_in" id="checkInB" value="<?=e($checkin)?>" required/>
              </div>
              <div class="fg">
                <label>Check-Out Date *</label>
                <input type="date" name="check_out" id="checkOutB" value="<?=e($checkout)?>" required/>
              </div>
            </div>
            <div class="fg">
              <label>Number of Guests</label>
              <select name="guests" id="guestsSelect">
                <option value="1">1 Guest</option>
                <option value="2" selected>2 Guests</option>
                <option value="3">3 Guests</option>
                <option value="4">4 Guests</option>
                <option value="5">5+ Guests</option>
              </select>
            </div>
            <div class="step-btns">
              <button type="button" class="btn-next" onclick="goStep(2)">Continue to Your Details <i class="fas fa-arrow-right"></i></button>
            </div>
          </div>

          <!-- STEP 2 -->
          <div class="form-step" id="step2">
            <h3 style="font-family:'Playfair Display',serif;font-size:1.4rem;color:#1a1a2e;margin-bottom:.4rem">Your Details</h3>
            <p style="color:#888;font-size:.88rem;margin-bottom:1.4rem">Personal information for your reservation.</p>
            <?php if(!isLoggedIn()): ?>
            <div class="inline-flash if-error" style="margin-bottom:1rem"><i class="fas fa-info-circle"></i> Please <a href="<?=BASE_URL?>pages/login.php" style="font-weight:700;color:#27ae60">sign in</a> or <a href="<?=BASE_URL?>pages/register.php" style="font-weight:700;color:#27ae60">register</a> to complete your booking.</div>
            <?php endif; ?>
            <div class="form-row-2" style="gap:1rem">
              <div class="fg"><label>First Name *</label><input type="text" name="first_name" placeholder="John" required/></div>
              <div class="fg"><label>Last Name *</label><input type="text" name="last_name" placeholder="Doe" required/></div>
            </div>
            <div class="form-row-2" style="gap:1rem">
              <div class="fg"><label>Email *</label><input type="email" name="email" value="<?=isLoggedIn()?e($pdo->query("SELECT email FROM users WHERE id={$_SESSION['user_id']}")->fetchColumn()):''?>" required/></div>
              <div class="fg"><label>Phone *</label><input type="tel" name="phone" placeholder="+233 20 000 0000" required/></div>
            </div>
            <div class="fg"><label>Special Requests (optional)</label><textarea name="special_requests" placeholder="e.g. early check-in, ground floor, extra pillows..."></textarea></div>
            <div class="step-btns">
              <button type="button" class="btn-prev" onclick="goStep(1)"><i class="fas fa-arrow-left"></i> Back</button>
              <button type="button" class="btn-next" onclick="goStep(3)">Continue to Payment <i class="fas fa-arrow-right"></i></button>
            </div>
          </div>

          <!-- STEP 3 -->
          <div class="form-step" id="step3">
            <h3 style="font-family:'Playfair Display',serif;font-size:1.4rem;color:#1a1a2e;margin-bottom:.4rem">Payment Method</h3>
            <p style="color:#888;font-size:.88rem;margin-bottom:1.4rem">Select how you'd like to pay.</p>
            <div class="pay-methods">
              <div class="popt sel" onclick="selPay(this,'card')"><i class="fas fa-credit-card"></i><span>Credit / Debit Card</span></div>
              <div class="popt" onclick="selPay(this,'mobile_money')"><i class="fas fa-mobile-alt"></i><span>Mobile Money</span></div>
              <div class="popt" onclick="selPay(this,'bank_transfer')"><i class="fas fa-university"></i><span>Bank Transfer</span></div>
              <div class="popt" onclick="selPay(this,'cash')"><i class="fas fa-money-bill-wave"></i><span>Pay at Hotel</span></div>
            </div>
            <input type="hidden" name="payment_method" id="payMethodInput" value="card"/>
            <div id="cardFields" style="border:1px solid #e0e0e0;border-radius:8px;padding:1.2rem;background:#fafafa">
              <div class="fg" style="margin-bottom:.8rem"><label>Cardholder Name</label><input type="text" placeholder="John Doe"/></div>
              <div class="fg" style="margin-bottom:.8rem"><label>Card Number</label><input type="text" placeholder="1234 5678 9012 3456" maxlength="19" oninput="this.value=this.value.replace(/\D/g,'').replace(/(.{4})/g,'$1 ').trim()"/></div>
              <div class="form-row-2" style="gap:.8rem">
                <div class="fg" style="margin:0"><label>Expiry (MM/YY)</label><input type="text" placeholder="09/27" maxlength="5"/></div>
                <div class="fg" style="margin:0"><label>CVV</label><input type="text" placeholder="123" maxlength="4"/></div>
              </div>
            </div>
            <div class="step-btns" style="margin-top:1.2rem">
              <button type="button" class="btn-prev" onclick="goStep(2)"><i class="fas fa-arrow-left"></i> Back</button>
              <button type="button" class="btn-next" onclick="goStep(4)">Review Booking <i class="fas fa-arrow-right"></i></button>
            </div>
          </div>

          <!-- STEP 4 -->
          <div class="form-step" id="step4">
            <h3 style="font-family:'Playfair Display',serif;font-size:1.4rem;color:#1a1a2e;margin-bottom:.4rem">Confirm Booking</h3>
            <p style="color:#888;font-size:.88rem;margin-bottom:1.4rem">Review your details before submitting.</p>
            <div id="confirmBox" style="background:#f7f9f7;border-radius:8px;padding:1.4rem;margin-bottom:1.2rem;font-size:.88rem;line-height:2"></div>
            <label style="display:flex;align-items:flex-start;gap:.7rem;color:#666;font-size:.84rem;margin-bottom:1.2rem;cursor:pointer">
              <input type="checkbox" required style="margin-top:3px;accent-color:#27ae60"/>
              I agree to the <a href="#" style="color:#27ae60">Booking Terms</a> and <a href="#" style="color:#27ae60">Cancellation Policy</a>.
            </label>
            <?php if(!isLoggedIn()): ?>
            <div class="inline-flash if-error"><i class="fas fa-lock"></i> You must <a href="<?=BASE_URL?>pages/login.php" style="font-weight:700">sign in</a> before confirming.</div>
            <?php else: ?>
            <div class="step-btns">
              <button type="button" class="btn-prev" onclick="goStep(3)"><i class="fas fa-arrow-left"></i> Back</button>
              <button type="submit" class="btn-next" style="background:#1a1a2e"><i class="fas fa-check-circle"></i> Confirm &amp; Book</button>
            </div>
            <?php endif; ?>
          </div>
        </form>
      </div>

      <!-- SUMMARY -->
      <div class="bsummary">
        <div class="bsum-title"><i class="fas fa-receipt" style="color:#27ae60;margin-right:.4rem"></i> Booking Summary</div>
        <div class="bsum-img" id="sumImg" style="background:url('<?=e($selectedRoom['image_url']??'')?>') center/cover"></div>
        <div class="bsum-row"><span class="lbl">Room</span><span class="val" id="sumRoom"><?=e($selectedRoom['type_name']??'—')?></span></div>
        <div class="bsum-row"><span class="lbl">Check-In</span><span class="val" id="sumCI"><?=fmtDate($checkin)?></span></div>
        <div class="bsum-row"><span class="lbl">Check-Out</span><span class="val" id="sumCO"><?=fmtDate($checkout)?></span></div>
        <div class="bsum-row"><span class="lbl">Nights</span><span class="val" id="sumNights">1</span></div>
        <div class="bsum-row"><span class="lbl">Price/Night</span><span class="val" id="sumPPN"><?=fmtCur($selectedRoom['price']??89)?></span></div>
        <div class="bsum-row"><span class="lbl">Tax (10%)</span><span class="val" id="sumTax">—</span></div>
        <div class="bsum-total"><span class="lbl">Total</span><span class="val" id="sumTotal">—</span></div>
        <div style="background:#e8f5ee;border-radius:6px;padding:.7rem;font-size:.8rem;color:#1e8449;margin-top:1rem"><i class="fas fa-shield-alt"></i> Free cancellation up to 24h before check-in</div>
      </div>
    </div>
  </div>
</section>

<script>
var curStep=1;
var curPrice=<?=$selectedRoom['price']??89?>;
var curRoomName='<?=addslashes($selectedRoom['type_name']??'Standard Room')?>';

function goStep(n){
  document.getElementById('step'+curStep).classList.remove('active');
  document.getElementById('sd'+curStep).classList.remove('active');
  document.getElementById('sd'+curStep).classList.add('done');
  curStep=n;
  document.getElementById('step'+n).classList.add('active');
  document.getElementById('sd'+n).classList.add('active');
  if(n===4)buildConfirm();
  window.scrollTo({top:300,behavior:'smooth'});
}
function selectRoom(el,id,name,price,img){
  document.querySelectorAll('.ropt').forEach(r=>r.classList.remove('sel'));
  el.classList.add('sel');
  document.getElementById('roomIdInput').value=id;
  curPrice=price; curRoomName=name;
  document.getElementById('sumRoom').textContent=name;
  document.getElementById('sumPPN').textContent='$'+price.toFixed(2);
  document.getElementById('sumImg').style.background="url('"+img+"') center/cover";
  updateTotal();
}
function selPay(el,method){
  document.querySelectorAll('.popt').forEach(p=>p.classList.remove('sel'));
  el.classList.add('sel');
  document.getElementById('payMethodInput').value=method;
  document.getElementById('cardFields').style.display=method==='card'?'block':'none';
}
function updateTotal(){
  var ci=document.getElementById('checkInB').value;
  var co=document.getElementById('checkOutB').value;
  var n=1;
  if(ci&&co){var d=(new Date(co)-new Date(ci))/86400000;if(d>0)n=d;}
  document.getElementById('sumNights').textContent=n;
  document.getElementById('sumCI').textContent=ci?new Date(ci).toLocaleDateString('en-GB',{day:'numeric',month:'short',year:'numeric'}):'—';
  document.getElementById('sumCO').textContent=co?new Date(co).toLocaleDateString('en-GB',{day:'numeric',month:'short',year:'numeric'}):'—';
  var sub=curPrice*n;
  var tax=sub*.1;
  document.getElementById('sumTax').textContent='$'+tax.toFixed(2);
  document.getElementById('sumTotal').textContent='$'+(sub+tax).toFixed(2);
}
function buildConfirm(){
  var ci=document.getElementById('checkInB').value;
  var co=document.getElementById('checkOutB').value;
  var n=document.getElementById('sumNights').textContent;
  var total=document.getElementById('sumTotal').textContent;
  var pay=document.getElementById('payMethodInput').value.replace(/_/g,' ');
  document.getElementById('confirmBox').innerHTML=
    '<table style="width:100%"><tbody>'+
    '<tr><td style="color:#888;padding:.3rem 0;width:40%">Room:</td><td style="font-weight:600">'+curRoomName+'</td></tr>'+
    '<tr><td style="color:#888;padding:.3rem 0">Check-In:</td><td style="font-weight:600">'+ci+'</td></tr>'+
    '<tr><td style="color:#888;padding:.3rem 0">Check-Out:</td><td style="font-weight:600">'+co+'</td></tr>'+
    '<tr><td style="color:#888;padding:.3rem 0">Duration:</td><td style="font-weight:600">'+n+' night(s)</td></tr>'+
    '<tr><td style="color:#888;padding:.3rem 0">Total:</td><td style="font-weight:700;color:#27ae60;font-size:1.1rem">'+total+'</td></tr>'+
    '<tr><td style="color:#888;padding:.3rem 0">Payment:</td><td style="font-weight:600;text-transform:capitalize">'+pay+'</td></tr>'+
    '</tbody></table>';
}
document.getElementById('checkInB').addEventListener('change',updateTotal);
document.getElementById('checkOutB').addEventListener('change',updateTotal);

// Init
var today=new Date().toISOString().split('T')[0];
var tmrw=new Date(Date.now()+86400000).toISOString().split('T')[0];
var ci=document.getElementById('checkInB');
var co=document.getElementById('checkOutB');
ci.min=today; co.min=tmrw;
updateTotal();
</script>

<?php include_footer(); ?>