<?php
require_once __DIR__.'/../includes/config.php';
require_once __DIR__.'/../includes/layout.php';
include_header('Gallery','gallery');
$gallery=[
  ['https://images.unsplash.com/photo-1631049307264-da0ec9d70304?w=800','rooms',   'Standard Room – Floor 1'],
  ['https://images.unsplash.com/photo-1618773928121-c32242e63f39?w=800','rooms',   'Deluxe Room – Floor 2'],
  ['https://images.unsplash.com/photo-1611892440504-42a792e24d32?w=800','rooms',   'Executive Suite – Floor 3'],
  ['https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?w=800','rooms',   'Family Room – Floor 4'],
  ['https://images.unsplash.com/photo-1590490360182-c33d57733427?w=800','rooms',   'Dormitory Beds'],
  ['https://images.unsplash.com/photo-1571902943202-507ec2618e8f?w=800','facilities','Outdoor Swimming Pool'],
  ['https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=800','facilities','Fitness Center'],
  ['https://images.unsplash.com/photo-1540497077202-7c8a3999166f?w=600','facilities','Spa & Wellness'],
  ['https://images.unsplash.com/photo-1497366216548-37526070297c?w=800','facilities','Conference Room'],
  ['https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=800','dining',  'Main Restaurant'],
  ['https://images.unsplash.com/photo-1551218808-94e220e084d2?w=800','dining',  'Pool Bar & Lounge'],
  ['https://images.unsplash.com/photo-1424847651672-bf20a4b0982b?w=800','dining',  'Breakfast Spread'],
  ['https://images.unsplash.com/photo-1566073771259-6a8506099945?w=800','exterior','Hotel Front Entrance'],
  ['https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?w=800','exterior','Lobby & Reception'],
  ['https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?w=800','exterior','Garden & Grounds'],
  ['https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?w=800','exterior','Aerial – Poolside View'],
];
$galleryJson = json_encode($gallery);
?>
<section class="page-hero" style="background:url('https://images.unsplash.com/photo-1611892440504-42a792e24d32?w=1400')center/cover;padding-top:70px">
  <div class="page-hero-content"><h1>Photo Gallery</h1><p class="breadcrumb"><a href="<?=BASE_URL?>index.php">Home</a> / <span>Gallery</span></p></div>
</section>
<section style="padding:5rem 0;background:#f7f9f7">
  <div class="container">
    <div class="section-header"><p class="section-tag">Visual Tour</p><h2 class="section-title">See Our <span>Property</span></h2><div class="divider"></div></div>
    <div class="filter-tabs" style="margin-top:2rem">
      <button class="ftab active" onclick="filterGal('all',this)">All Photos</button>
      <button class="ftab" onclick="filterGal('rooms',this)">Rooms</button>
      <button class="ftab" onclick="filterGal('facilities',this)">Facilities</button>
      <button class="ftab" onclick="filterGal('dining',this)">Dining</button>
      <button class="ftab" onclick="filterGal('exterior',this)">Exterior</button>
    </div>
    <div class="gal-grid" id="galGrid"></div>
  </div>
</section>

<!-- LIGHTBOX -->
<div class="lightbox" id="lightbox">
  <div class="lb-inner">
    <button class="lb-close" onclick="closeLb()"><i class="fas fa-times"></i></button>
    <button class="lb-prev" onclick="lbNav(-1)"><i class="fas fa-chevron-left"></i></button>
    <img id="lbImg" src="" alt=""/>
    <button class="lb-next" onclick="lbNav(1)"><i class="fas fa-chevron-right"></i></button>
    <p class="lb-cap" id="lbCap"></p>
  </div>
</div>

<script>
const GALLERY=<?=$galleryJson?>;
let curFilter='all', curIdx=0, filtered=[...GALLERY];
function filterGal(cat,btn){
  curFilter=cat;
  document.querySelectorAll('.ftab').forEach(t=>t.classList.remove('active'));
  btn.classList.add('active');
  filtered=cat==='all'?GALLERY:GALLERY.filter(g=>g[1]===cat);
  renderGal();
}
function renderGal(){
  const g=document.getElementById('galGrid');
  g.innerHTML=filtered.map((item,i)=>`
    <div class="gal-item" onclick="openLb(${i})">
      <img src="${item[0]}&auto=format&q=75&w=400" alt="${item[2]}" loading="lazy"/>
      <div class="gal-overlay"><i class="fas fa-expand-alt"></i><span>${item[2]}</span></div>
    </div>`).join('');
}
function openLb(i){curIdx=i;updateLb();document.getElementById('lightbox').classList.add('open');document.body.style.overflow='hidden';}
function updateLb(){const it=filtered[curIdx];document.getElementById('lbImg').src=it[0];document.getElementById('lbCap').textContent=it[2]+' ('+(curIdx+1)+'/'+filtered.length+')';}
function lbNav(d){curIdx=(curIdx+d+filtered.length)%filtered.length;updateLb();}
function closeLb(){document.getElementById('lightbox').classList.remove('open');document.body.style.overflow='';}
document.getElementById('lightbox').addEventListener('click',function(e){if(e.target===this)closeLb();});
document.addEventListener('keydown',e=>{if(!document.getElementById('lightbox').classList.contains('open'))return;if(e.key==='ArrowRight')lbNav(1);if(e.key==='ArrowLeft')lbNav(-1);if(e.key==='Escape')closeLb();});
renderGal();
</script>
<?php include_footer(); ?>
