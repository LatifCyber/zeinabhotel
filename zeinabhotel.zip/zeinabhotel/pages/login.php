<?php
require_once __DIR__.'/../includes/config.php';
if (isLoggedIn()) {
    redirect(isAdmin() ? BASE_URL.'pages/admin/dashboard.php' : BASE_URL.'pages/dashboard.php');
}
$flash = getFlash();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<title>Sign In – HBMS</title>
<link rel="stylesheet" href="<?=BASE_URL?>css/style.css"/>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Jost:wght@300;400;500;600&display=swap" rel="stylesheet"/>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>
</head>
<body>
<div class="auth-wrap">
  <!-- VISUAL SIDE -->
  <div class="auth-visual" style="background:url('https://images.unsplash.com/photo-1566073771259-6a8506099945?w=900')center/cover">
    <div class="auth-visual-content">
      <h2>Welcome Back</h2>
      <p>Sign in to manage your bookings, access exclusive deals, and enjoy a seamless hospitality experience.</p>
    </div>
  </div>

  <!-- FORM SIDE -->
  <div class="auth-form-side">
    <div class="auth-logo"><a href="<?=BASE_URL?>index.php" style="color:inherit"><span>H</span>BMS</a></div>
    <h2 class="auth-title">Sign In</h2>
    <p class="auth-sub">Enter your credentials to continue</p>

    <?php if($flash): ?>
    <div class="inline-flash <?=$flash['type']==='success'?'if-success':'if-error'?>">
      <i class="fas fa-<?=$flash['type']==='success'?'check-circle':'exclamation-circle'?>"></i>
      <?=e($flash['msg'])?>
    </div>
    <?php endif; ?>

    <form action="<?=BASE_URL?>php/auth.php?action=login" method="POST">
      <div class="form-group">
        <label>Email Address</label>
        <div class="input-wrap">
          <i class="fas fa-envelope input-icon"></i>
          <input type="email" name="email" placeholder="admin@hbms.com" required autocomplete="email"/>
        </div>
      </div>
      <div class="form-group">
        <label>Password</label>
        <div class="input-wrap">
          <i class="fas fa-lock input-icon"></i>
          <input type="password" name="password" id="pwd" placeholder="Enter your password" required autocomplete="current-password"/>
          <button type="button" class="input-eye" onclick="togglePwd()"><i class="fas fa-eye" id="eyeIcon"></i></button>
        </div>
      </div>
      <div class="auth-row">
        <label class="auth-check">
          <input type="checkbox" name="remember"/> Remember me
        </label>
        <a href="#" class="forgot-link">Forgot Password?</a>
      </div>
      <button type="submit" class="btn-submit"><i class="fas fa-sign-in-alt"></i> &nbsp;Sign In</button>
    </form>

    <div class="auth-divider">or</div>
    <p class="auth-switch">Don't have an account? <a href="<?=BASE_URL?>pages/register.php">Create one free</a></p>
    <p class="auth-switch" style="margin-top:.6rem"><a href="<?=BASE_URL?>index.php"><i class="fas fa-arrow-left"></i> Back to Home</a></p>

    <!-- DEMO CREDENTIALS 
    <div style="margin-top:2rem;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:8px;padding:1rem;font-size:.78rem;color:rgba(255,255,255,.5)">
      <strong style="color:rgba(255,255,255,.7)">Demo credentials:</strong><br/>
      Admin: admin@hbms.com &nbsp;|&nbsp; Staff: staff@hbms.com &nbsp;|&nbsp; Guest: guest@hbms.com<br/>
      Password for all: <strong style="color:#27ae60">password</strong>
    </div>
-->
  </div>
</div>
<script>
function togglePwd(){
  const p=document.getElementById('pwd');
  const e=document.getElementById('eyeIcon');
  p.type=p.type==='password'?'text':'password';
  e.className='fas fa-'+(p.type==='text'?'eye-slash':'eye');
}
</script>
</body>
</html>
