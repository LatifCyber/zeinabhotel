<?php
require_once __DIR__.'/../../includes/config.php';
require_once __DIR__.'/../../includes/admin_layout.php';
requireAdmin();

// Toggle status
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['toggle'])) {
    $uid    = (int)$_POST['user_id'];
    $status = sanitize($_POST['status']);
    if (in_array($status,['active','inactive'])) {
        $pdo->prepare("UPDATE users SET status=? WHERE id=? AND role='guest'")->execute([$status,$uid]);
        flash('success','Guest status updated.');
    }
    redirect(BASE_URL.'pages/admin/guests.php');
}

$search  = sanitize($_GET['q'] ?? '');
$page    = max(1,(int)($_GET['page']??1));
$perPage = 15;
$offset  = ($page-1)*$perPage;

$where = "WHERE role='guest'"; $params=[];
if ($search) { $where .= " AND (name LIKE ? OR email LIKE ? OR phone LIKE ?)"; $p="%$search%"; $params=[$p,$p,$p]; }

$total = $pdo->prepare("SELECT COUNT(*) FROM users $where");
$total->execute($params); $total=(int)$total->fetchColumn();
$pages = max(1,ceil($total/$perPage));

$stmt = $pdo->prepare("
  SELECT u.*,
    (SELECT COUNT(*) FROM bookings WHERE user_id=u.id) AS total_bookings,
    (SELECT COALESCE(SUM(total_amount),0) FROM bookings WHERE user_id=u.id AND payment_status='paid') AS total_spent
  FROM users u $where ORDER BY u.created_at DESC LIMIT $perPage OFFSET $offset
");
$stmt->execute($params);
$guests = $stmt->fetchAll();

admin_header('Guest Management');
?>
<div class="fbar">
  <form method="GET" style="display:contents">
    <input type="text" name="q" placeholder="Search by name, email or phone…" value="<?=e($search)?>"/>
    <button type="submit" class="btn-sm"><i class="fas fa-search"></i> Search</button>
    <?php if($search): ?><a href="guests.php" style="font-size:.83rem;color:#888;padding:.5rem">✕ Clear</a><?php endif; ?>
  </form>
</div>
<p style="color:#888;font-size:.83rem;margin-bottom:.8rem">Total: <strong style="color:#27ae60"><?=$total?></strong> guest<?=$total!==1?'s':''?></p>

<div class="d-card">
  <div class="tbl-wrap">
    <table class="d-table">
      <thead><tr><th>#</th><th>Guest</th><th>Email</th><th>Phone</th><th>Bookings</th><th>Total Spent</th><th>Status</th><th>Joined</th><th>Action</th></tr></thead>
      <tbody>
      <?php if(empty($guests)): ?>
      <tr><td colspan="9" style="text-align:center;padding:3rem;color:#aaa">No guests found.</td></tr>
      <?php else: ?>
      <?php foreach($guests as $i=>$g): ?>
      <tr>
        <td><?=$offset+$i+1?></td>
        <td>
          <div style="display:flex;align-items:center;gap:.7rem">
            <div style="width:34px;height:34px;border-radius:50%;background:#27ae60;color:#fff;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:.78rem;flex-shrink:0"><?=strtoupper(substr($g['name'],0,2))?></div>
            <strong style="color:#1a1a2e"><?=e($g['name'])?></strong>
          </div>
        </td>
        <td><?=e($g['email'])?></td>
        <td><?=e($g['phone']??'—')?></td>
        <td><span style="background:#e8f5ee;color:#27ae60;font-weight:700;padding:.2rem .7rem;border-radius:20px;font-size:.78rem"><?=$g['total_bookings']?></span></td>
        <td><strong><?=fmtCur($g['total_spent'])?></strong></td>
        <td>
          <span style="background:<?=$g['status']==='active'?'#d4edda':'#f8d7da'?>;color:<?=$g['status']==='active'?'#155724':'#721c24'?>;padding:.22rem .65rem;border-radius:20px;font-size:.7rem;font-weight:700;text-transform:uppercase"><?=ucfirst($g['status'])?></span>
        </td>
        <td><?=fmtDate($g['created_at'])?></td>
        <td>
          <form method="POST" style="display:inline">
            <input type="hidden" name="user_id" value="<?=$g['id']?>"/>
            <input type="hidden" name="status" value="<?=$g['status']==='active'?'inactive':'active'?>"/>
            <button type="submit" name="toggle" class="<?=$g['status']==='active'?'btn-sm-red':'btn-sm-dark'?>" style="font-size:.75rem">
              <?=$g['status']==='active'?'Deactivate':'Activate'?>
            </button>
          </form>
        </td>
      </tr>
      <?php endforeach; ?>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
  <?php if($pages>1): ?>
  <div class="pagination">
    <?php if($page>1): ?><a href="?q=<?=e($search)?>&page=<?=$page-1?>"><i class="fas fa-chevron-left"></i></a><?php endif; ?>
    <?php for($p=max(1,$page-2);$p<=min($pages,$page+2);$p++): ?>
    <?php if($p===$page): ?><span class="cur"><?=$p?></span><?php else: ?><a href="?q=<?=e($search)?>&page=<?=$p?>"><?=$p?></a><?php endif; ?>
    <?php endfor; ?>
    <?php if($page<$pages): ?><a href="?q=<?=e($search)?>&page=<?=$page+1?>"><i class="fas fa-chevron-right"></i></a><?php endif; ?>
  </div>
  <?php endif; ?>
</div>
<?php admin_footer(); ?>
