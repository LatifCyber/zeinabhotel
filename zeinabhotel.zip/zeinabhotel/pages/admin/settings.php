<?php
require_once __DIR__.'/../../includes/config.php';
require_once __DIR__.'/../../includes/admin_layout.php';
requireAdmin();

// Save profile
if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['section']??'')==='profile') {
    $name  = sanitize($_POST['name']);
    $email = sanitize($_POST['email']);
    if (!$name || !filter_var($email,FILTER_VALIDATE_EMAIL)) {
        flash('error','Please enter a valid name and email.');
    } else {
        $pdo->prepare("UPDATE users SET name=?,email=? WHERE id=?")->execute([$name,$email,$_SESSION['user_id']]);
        $_SESSION['user_name'] = $name;
        if (!empty($_POST['new_password'])) {
            if (strlen($_POST['new_password']) < 6) { flash('error','Password must be at least 6 characters.'); }
            else {
                $hash = password_hash($_POST['new_password'], PASSWORD_BCRYPT);
                $pdo->prepare("UPDATE users SET password=? WHERE id=?")->execute([$hash,$_SESSION['user_id']]);
                flash('success','Profile and password updated.');
            }
        } else {
            flash('success','Profile updated successfully.');
        }
    }
    redirect(BASE_URL.'pages/admin/settings.php');
}

$admin = $pdo->prepare("SELECT * FROM users WHERE id=?");
$admin->execute([$_SESSION['user_id']]); $admin = $admin->fetch();

$sysInfo = [
    'PHP Version'    => phpversion(),
    'Total Rooms'    => $pdo->query("SELECT COUNT(*) FROM rooms")->fetchColumn(),
    'Total Users'    => $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn(),
    'Total Bookings' => $pdo->query("SELECT COUNT(*) FROM bookings")->fetchColumn(),
    'Total Revenue'  => fmtCur($pdo->query("SELECT COALESCE(SUM(total_amount),0) FROM bookings WHERE payment_status='paid'")->fetchColumn()),
    'Unread Messages'=> $pdo->query("SELECT COUNT(*) FROM contact_messages WHERE is_read=0")->fetchColumn(),
];

admin_header('Settings');
?>
<div style="max-width:780px">

  <!-- PROFILE CARD -->
  <div class="d-card" style="margin-bottom:1.5rem">
    <div class="d-card-header"><h3>Admin Profile</h3></div>
    <div style="padding:1.8rem">
      <div style="display:flex;align-items:center;gap:1.2rem;margin-bottom:1.8rem">
        <div style="width:72px;height:72px;border-radius:50%;background:#27ae60;color:#fff;display:flex;align-items:center;justify-content:center;font-family:'Playfair Display',serif;font-size:1.6rem;font-weight:700;flex-shrink:0"><?=strtoupper(substr($admin['name'],0,2))?></div>
        <div>
          <strong style="display:block;color:#1a1a2e;font-size:1rem"><?=e($admin['name'])?></strong>
          <span style="color:#888;font-size:.85rem"><?=e($admin['email'])?></span><br/>
          <span style="background:#e8f5ee;color:#27ae60;padding:.18rem .65rem;border-radius:10px;font-weight:600;font-size:.72rem;display:inline-block;margin-top:.3rem"><?=ucfirst($admin['role'])?></span>
        </div>
      </div>
      <form method="POST">
        <input type="hidden" name="section" value="profile"/>
        <div class="form-row-2" style="gap:1rem;display:grid;grid-template-columns:1fr 1fr">
          <div class="mfg"><label>Full Name *</label><input type="text" name="name" value="<?=e($admin['name'])?>" required/></div>
          <div class="mfg"><label>Email Address *</label><input type="email" name="email" value="<?=e($admin['email'])?>" required/></div>
        </div>
        <div class="form-row-2" style="gap:1rem;display:grid;grid-template-columns:1fr 1fr">
          <div class="mfg"><label>New Password <small style="text-transform:none;letter-spacing:0">(leave blank to keep current)</small></label><input type="password" name="new_password" placeholder="New password"/></div>
          <div class="mfg"><label>Role</label><input type="text" value="<?=ucfirst($admin['role'])?>" readonly style="background:#f5f5f5;color:#888;cursor:not-allowed"/></div>
        </div>
        <button type="submit" class="btn-sm" style="padding:.7rem 2rem"><i class="fas fa-save"></i> Save Changes</button>
      </form>
    </div>
  </div>

  <!-- SYSTEM INFO -->
  <div class="d-card" style="margin-bottom:1.5rem">
    <div class="d-card-header"><h3>System Overview</h3></div>
    <div style="padding:1.5rem;display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:1rem">
      <?php foreach($sysInfo as $label=>$val): ?>
      <div style="background:#f7f9f7;border-radius:8px;padding:1rem;text-align:center">
        <div style="font-family:'Playfair Display',serif;font-size:1.3rem;color:#1a1a2e;font-weight:700"><?=$val?></div>
        <div style="font-size:.72rem;color:#888;margin-top:.2rem"><?=$label?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>

  <!-- DB CONFIG -->
  <div class="d-card">
    <div class="d-card-header"><h3>Database Configuration</h3></div>
    <div style="padding:1.5rem;display:grid;grid-template-columns:1fr 1fr;gap:1rem">
      <?php foreach(['Host'=>DB_HOST,'Database'=>DB_NAME,'User'=>DB_USER,'Site Name'=>SITE_NAME] as $label=>$val): ?>
      <div class="mfg"><label><?=$label?></label><input type="text" value="<?=e($val)?>" readonly style="background:#f5f5f5;color:#888;cursor:not-allowed"/></div>
      <?php endforeach; ?>
    </div>
  </div>

</div>
<?php admin_footer(); ?>
