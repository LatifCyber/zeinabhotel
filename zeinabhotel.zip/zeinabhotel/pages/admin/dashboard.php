<?php
require_once __DIR__.'/../../includes/config.php';
require_once __DIR__.'/../../includes/admin_layout.php';
requireAdmin();

$stats=[
  'rooms'     => $pdo->query("SELECT COUNT(*) FROM rooms")->fetchColumn(),
  'available' => $pdo->query("SELECT COUNT(*) FROM rooms WHERE status='available'")->fetchColumn(),
  'bookings'  => $pdo->query("SELECT COUNT(*) FROM bookings")->fetchColumn(),
  'pending'   => $pdo->query("SELECT COUNT(*) FROM bookings WHERE status='pending'")->fetchColumn(),
  'guests'    => $pdo->query("SELECT COUNT(*) FROM users WHERE role='guest'")->fetchColumn(),
  'revenue'   => $pdo->query("SELECT COALESCE(SUM(total_amount),0) FROM bookings WHERE payment_status='paid'")->fetchColumn(),
];
$recent = $pdo->query("SELECT b.*,u.name AS gname,r.room_number,rt.name AS rtype FROM bookings b JOIN users u ON b.user_id=u.id JOIN rooms r ON b.room_id=r.id JOIN room_types rt ON r.type_id=rt.id ORDER BY b.created_at DESC LIMIT 8")->fetchAll();

admin_header('Dashboard Overview');
?>
<div class="stats-row">
  <?php $cards=[
    ['Total Rooms',    $stats['rooms'],    '#e8f5ee','#27ae60','fa-bed'],
    ['Available',      $stats['available'],'#e3f2fd','#1976d2','fa-door-open'],
    ['All Bookings',   $stats['bookings'], '#fff8e1','#f57f17','fa-calendar-check'],
    ['Pending',        $stats['pending'],  '#fce4ec','#e91e63','fa-clock'],
    ['Guests',         $stats['guests'],   '#f3e5f5','#9c27b0','fa-users'],
    ['Revenue',        fmtCur($stats['revenue']),'#e0f2f1','#009688','fa-dollar-sign'],
  ];
  foreach($cards as [$label,$val,$bg,$col,$icon]): ?>
  <div class="s-card"><div class="s-icon" style="background:<?=$bg?>"><i class="fas <?=$icon?>" style="color:<?=$col?>"></i></div><div class="s-body"><p><?=$label?></p><h3><?=$val?></h3></div></div>
  <?php endforeach; ?>
</div>

<div class="d-card">
  <div class="d-card-header"><h3><i class="fas fa-list" style="color:#27ae60;margin-right:.4rem"></i> Recent Bookings</h3><a href="<?=BASE_URL?>pages/admin/bookings.php">View All →</a></div>
  <div class="tbl-wrap">
    <table class="d-table">
      <thead><tr><th>Ref</th><th>Guest</th><th>Room</th><th>Check-In</th><th>Check-Out</th><th>Amount</th><th>Status</th></tr></thead>
      <tbody>
      <?php if(empty($recent)): ?>
      <tr><td colspan="7" style="text-align:center;padding:2rem;color:#aaa">No bookings yet.</td></tr>
      <?php else: ?>
      <?php foreach($recent as $b): ?>
      <tr>
        <td><strong><?=e($b['booking_ref'])?></strong></td>
        <td><?=e($b['gname'])?></td>
        <td><?=e($b['room_number'])?> – <?=e($b['rtype'])?></td>
        <td><?=fmtDate($b['check_in'])?></td>
        <td><?=fmtDate($b['check_out'])?></td>
        <td><strong><?=fmtCur($b['total_amount'])?></strong></td>
        <td><span class="sb sb-<?=$b['status']?>"><?=ucfirst(str_replace('_',' ',$b['status']))?></span></td>
      </tr>
      <?php endforeach; ?>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php admin_footer(); ?>
