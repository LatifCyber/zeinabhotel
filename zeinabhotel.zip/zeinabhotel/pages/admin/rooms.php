<?php
require_once __DIR__.'/../../includes/config.php';
require_once __DIR__.'/../../includes/admin_layout.php';
requireAdmin();

// Add room
if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['action']??'')==='add') {
    $num    = sanitize($_POST['room_number']);
    $typeId = (int)$_POST['type_id'];
    $floor  = (int)$_POST['floor'];
    try {
        $pdo->prepare("INSERT INTO rooms (room_number,type_id,floor) VALUES (?,?,?)")->execute([$num,$typeId,$floor]);
        flash('success',"Room $num added successfully.");
    } catch(Exception $e) {
        flash('error','Room number already exists.');
    }
    redirect(BASE_URL.'pages/admin/rooms.php');
}
// Update status
if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['action']??'')==='status') {
    $rid    = (int)$_POST['room_id'];
    $status = sanitize($_POST['status']);
    if (in_array($status,['available','maintenance','reserved'])) {
        $pdo->prepare("UPDATE rooms SET status=? WHERE id=?")->execute([$status,$rid]);
        flash('success','Room status updated.');
    }
    redirect(BASE_URL.'pages/admin/rooms.php');
}
// Delete room
if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['action']??'')==='delete') {
    $rid = (int)$_POST['room_id'];
    $pdo->prepare("DELETE FROM rooms WHERE id=? AND status!='occupied'")->execute([$rid]);
    flash('success','Room deleted.');
    redirect(BASE_URL.'pages/admin/rooms.php');
}

$rooms     = $pdo->query("SELECT r.*,rt.name AS tname,rt.price FROM rooms r JOIN room_types rt ON r.type_id=rt.id ORDER BY r.floor,r.room_number")->fetchAll();
$roomTypes = $pdo->query("SELECT * FROM room_types ORDER BY price")->fetchAll();

$statusStyle = [
    'available'   => 'background:#d4edda;color:#155724',
    'occupied'    => 'background:#fff3cd;color:#856404',
    'maintenance' => 'background:#f8d7da;color:#721c24',
    'reserved'    => 'background:#cce5ff;color:#004085',
];
$borderColor = ['available'=>'#27ae60','occupied'=>'#f39c12','maintenance'=>'#e74c3c','reserved'=>'#3498db'];

admin_header('Room Management');
?>
<div style="display:flex;justify-content:flex-end;margin-bottom:1.2rem">
  <button class="btn-sm" onclick="document.getElementById('addModal').classList.add('open')"><i class="fas fa-plus"></i> Add Room</button>
</div>

<!-- LEGEND -->
<div style="background:#fff;border-radius:8px;padding:.9rem 1.3rem;margin-bottom:1.3rem;display:flex;gap:1.5rem;flex-wrap:wrap;box-shadow:0 2px 8px rgba(0,0,0,.05);font-size:.82rem;color:#666">
  <?php foreach(['available'=>'#27ae60','occupied'=>'#f39c12','maintenance'=>'#e74c3c','reserved'=>'#3498db'] as $s=>$c): ?>
  <span style="display:flex;align-items:center;gap:.4rem"><span style="width:12px;height:12px;border-radius:50%;background:<?=$c?>;display:inline-block"></span><?=ucfirst($s)?></span>
  <?php endforeach; ?>
</div>

<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(195px,1fr));gap:1.1rem;margin-bottom:2rem">
  <?php foreach($rooms as $r): ?>
  <div style="background:#fff;border-radius:10px;padding:1.2rem;box-shadow:0 2px 10px rgba(0,0,0,.06);transition:all .3s;border-top:4px solid <?=$borderColor[$r['status']]??'#ccc'?>" onmouseover="this.style.transform='translateY(-4px)'" onmouseout="this.style.transform=''">
    <h3 style="font-family:'Playfair Display',serif;font-size:1.15rem;color:#1a1a2e;margin-bottom:.25rem">Room <?=e($r['room_number'])?></h3>
    <div style="font-size:.78rem;color:#888;margin-bottom:.4rem"><?=e($r['tname'])?></div>
    <div style="font-size:.95rem;font-weight:700;color:#27ae60;margin-bottom:.4rem">$<?=number_format($r['price'],0)?>/night</div>
    <div style="font-size:.75rem;color:#aaa;margin-bottom:.7rem"><i class="fas fa-layer-group"></i> Floor <?=$r['floor']===0?'G':$r['floor']?></div>
    <span style="<?=$statusStyle[$r['status']]??''?>;display:inline-block;padding:.2rem .65rem;border-radius:20px;font-size:.68rem;font-weight:700;text-transform:uppercase"><?=ucfirst($r['status'])?></span>
    <?php if($r['status']!=='occupied'): ?>
    <form method="POST" style="margin-top:.8rem;display:flex;gap:.3rem">
      <input type="hidden" name="action" value="status"/>
      <input type="hidden" name="room_id" value="<?=$r['id']?>"/>
      <select name="status" style="flex:1;border:1px solid #e0e0e0;border-radius:5px;padding:.3rem .5rem;font-size:.75rem;outline:none">
        <?php foreach(['available','maintenance','reserved'] as $s): ?>
        <option value="<?=$s?>" <?=$r['status']===$s?'selected':''?>><?=ucfirst($s)?></option>
        <?php endforeach; ?>
      </select>
      <button type="submit" class="btn-sm-dark" title="Update"><i class="fas fa-save"></i></button>
    </form>
    <form method="POST" style="margin-top:.3rem" onsubmit="return confirm('Delete Room <?=e($r['room_number'])?>?')">
      <input type="hidden" name="action" value="delete"/>
      <input type="hidden" name="room_id" value="<?=$r['id']?>"/>
      <button type="submit" class="btn-sm-red" style="width:100%"><i class="fas fa-trash"></i> Delete</button>
    </form>
    <?php else: ?>
    <div style="font-size:.75rem;color:#aaa;margin-top:.7rem;font-style:italic">Currently occupied – cannot edit</div>
    <?php endif; ?>
  </div>
  <?php endforeach; ?>
</div>

<!-- ADD MODAL -->
<div class="modal-back" id="addModal">
  <div class="modal-box">
    <h3><i class="fas fa-plus-circle" style="color:#27ae60;margin-right:.5rem"></i> Add New Room</h3>
    <form method="POST">
      <input type="hidden" name="action" value="add"/>
      <div class="mfg"><label>Room Number *</label><input type="text" name="room_number" placeholder="e.g. 105, D03" required/></div>
      <div class="mfg"><label>Room Type *</label>
        <select name="type_id" required>
          <?php foreach($roomTypes as $rt): ?>
          <option value="<?=$rt['id']?>"><?=e($rt['name'])?> – $<?=$rt['price']?>/night</option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="mfg"><label>Floor (0 = Ground)</label><input type="number" name="floor" value="1" min="0" max="30" required/></div>
      <div class="modal-btns">
        <button type="button" class="btn-mcancel" onclick="document.getElementById('addModal').classList.remove('open')">Cancel</button>
        <button type="submit" class="btn-msubmit"><i class="fas fa-save"></i> Save Room</button>
      </div>
    </form>
  </div>
</div>
<script>document.getElementById('addModal').addEventListener('click',function(e){if(e.target===this)this.classList.remove('open')});</script>
<?php admin_footer(); ?>
