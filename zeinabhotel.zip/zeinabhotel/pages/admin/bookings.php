<?php
require_once __DIR__.'/../../includes/config.php';
require_once __DIR__.'/../../includes/admin_layout.php';
requireAdmin();

// Update status
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['update_status'])) {
    $bid    = (int)$_POST['booking_id'];
    $status = sanitize($_POST['new_status']);
    $pay    = sanitize($_POST['pay_status'] ?? '');
    $allowed = ['pending','confirmed','checked_in','checked_out','cancelled'];
    if (in_array($status,$allowed)) {
        $pdo->prepare("UPDATE bookings SET status=? WHERE id=?")->execute([$status,$bid]);
    }
    if ($pay && in_array($pay,['unpaid','paid','refunded'])) {
        $pdo->prepare("UPDATE bookings SET payment_status=? WHERE id=?")->execute([$pay,$bid]);
    }
    flash('success','Booking updated successfully.');
    redirect(BASE_URL.'pages/admin/bookings.php');
}

$search  = sanitize($_GET['q']      ?? '');
$filter  = sanitize($_GET['status'] ?? '');
$page    = max(1,(int)($_GET['page'] ?? 1));
$perPage = 15;
$offset  = ($page-1)*$perPage;

$where = "WHERE 1=1"; $params = [];
if ($search) { $where .= " AND (b.booking_ref LIKE ? OR u.name LIKE ? OR u.email LIKE ?)"; $p="%$search%"; $params=[$p,$p,$p]; }
if ($filter)  { $where .= " AND b.status=?"; $params[] = $filter; }

$total = $pdo->prepare("SELECT COUNT(*) FROM bookings b JOIN users u ON b.user_id=u.id $where");
$total->execute($params); $total=(int)$total->fetchColumn();
$pages = max(1,ceil($total/$perPage));

$stmt = $pdo->prepare("
  SELECT b.*,u.name AS gname,u.email AS gemail,r.room_number,rt.name AS rtype
  FROM bookings b
  JOIN users u ON b.user_id=u.id
  JOIN rooms r ON b.room_id=r.id
  JOIN room_types rt ON r.type_id=rt.id
  $where ORDER BY b.created_at DESC LIMIT $perPage OFFSET $offset
");
$stmt->execute($params);
$bookings = $stmt->fetchAll();

admin_header('Manage Bookings');
?>
<div class="fbar">
  <form method="GET" style="display:contents">
    <input type="text" name="q" placeholder="Search ref, name or email…" value="<?=e($search)?>"/>
    <select name="status">
      <option value="">All Statuses</option>
      <?php foreach(['pending','confirmed','checked_in','checked_out','cancelled'] as $s): ?>
      <option value="<?=$s?>" <?=$filter===$s?'selected':''?>><?=ucfirst(str_replace('_',' ',$s))?></option>
      <?php endforeach; ?>
    </select>
    <button type="submit" class="btn-sm"><i class="fas fa-search"></i> Filter</button>
    <?php if($search||$filter): ?><a href="bookings.php" style="font-size:.83rem;color:#888;padding:.5rem">✕ Clear</a><?php endif; ?>
  </form>
</div>
<p style="color:#888;font-size:.83rem;margin-bottom:.8rem">Showing <strong style="color:#27ae60"><?=count($bookings)?></strong> of <strong><?=$total?></strong> bookings</p>

<div class="d-card">
  <div class="tbl-wrap">
    <table class="d-table">
      <thead><tr><th>#</th><th>Ref</th><th>Guest</th><th>Room</th><th>Check-In</th><th>Check-Out</th><th>Amount</th><th>Status</th><th>Payment</th><th>Update</th></tr></thead>
      <tbody>
      <?php if(empty($bookings)): ?>
      <tr><td colspan="10" style="text-align:center;padding:3rem;color:#aaa"><i class="fas fa-calendar-times" style="font-size:2rem;display:block;margin-bottom:.5rem;color:#ddd"></i>No bookings found.</td></tr>
      <?php else: ?>
      <?php foreach($bookings as $i=>$b): ?>
      <tr>
        <td><?=$offset+$i+1?></td>
        <td><strong><?=e($b['booking_ref'])?></strong></td>
        <td>
          <div style="font-weight:600;color:#1a1a2e;font-size:.88rem"><?=e($b['gname'])?></div>
          <div style="font-size:.75rem;color:#888"><?=e($b['gemail'])?></div>
        </td>
        <td><?=e($b['room_number'])?> <small style="color:#888">– <?=e($b['rtype'])?></small></td>
        <td><?=fmtDate($b['check_in'])?></td>
        <td><?=fmtDate($b['check_out'])?></td>
        <td><strong><?=fmtCur($b['total_amount'])?></strong></td>
        <td><span class="sb sb-<?=$b['status']?>"><?=ucfirst(str_replace('_',' ',$b['status']))?></span></td>
        <td><span class="sb sb-<?=$b['payment_status']?>"><?=ucfirst($b['payment_status'])?></span></td>
        <td>
          <form method="POST" style="display:flex;gap:.3rem;align-items:center">
            <input type="hidden" name="booking_id" value="<?=$b['id']?>"/>
            <select name="new_status" style="border:1px solid #e0e0e0;border-radius:4px;padding:.28rem .5rem;font-size:.75rem;outline:none">
              <?php foreach(['pending','confirmed','checked_in','checked_out','cancelled'] as $s): ?>
              <option value="<?=$s?>" <?=$b['status']===$s?'selected':''?>><?=ucfirst(str_replace('_',' ',$s))?></option>
              <?php endforeach; ?>
            </select>
            <select name="pay_status" style="border:1px solid #e0e0e0;border-radius:4px;padding:.28rem .5rem;font-size:.75rem;outline:none">
              <?php foreach(['unpaid','paid','refunded'] as $s): ?>
              <option value="<?=$s?>" <?=$b['payment_status']===$s?'selected':''?>><?=ucfirst($s)?></option>
              <?php endforeach; ?>
            </select>
            <button type="submit" name="update_status" class="btn-sm-dark" title="Save"><i class="fas fa-save"></i></button>
          </form>
        </td>
      </tr>
      <?php endforeach; ?>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
  <?php if($pages>1): ?>
  <div class="pagination">
    <?php if($page>1): ?><a href="?q=<?=e($search)?>&status=<?=e($filter)?>&page=<?=$page-1?>"><i class="fas fa-chevron-left"></i></a><?php endif; ?>
    <?php for($p=max(1,$page-2);$p<=min($pages,$page+2);$p++): ?>
    <?php if($p===$page): ?><span class="cur"><?=$p?></span><?php else: ?><a href="?q=<?=e($search)?>&status=<?=e($filter)?>&page=<?=$p?>"><?=$p?></a><?php endif; ?>
    <?php endfor; ?>
    <?php if($page<$pages): ?><a href="?q=<?=e($search)?>&status=<?=e($filter)?>&page=<?=$page+1?>"><i class="fas fa-chevron-right"></i></a><?php endif; ?>
  </div>
  <?php endif; ?>
</div>
<?php admin_footer(); ?>
