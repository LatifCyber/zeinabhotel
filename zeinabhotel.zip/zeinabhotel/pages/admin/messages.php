<?php
require_once __DIR__.'/../../includes/config.php';
require_once __DIR__.'/../../includes/admin_layout.php';
requireAdmin();

// Delete
if (isset($_GET['delete']) && $_SESSION['role']==='admin') {
    $pdo->prepare("DELETE FROM contact_messages WHERE id=?")->execute([(int)$_GET['delete']]);
    flash('success','Message deleted.');
    redirect(BASE_URL.'pages/admin/messages.php');
}
// Mark read
if (isset($_GET['read'])) {
    $pdo->prepare("UPDATE contact_messages SET is_read=1 WHERE id=?")->execute([(int)$_GET['read']]);
    redirect(BASE_URL.'pages/admin/messages.php?id='.(int)$_GET['read'].'&filter='.sanitize($_GET['filter']??''));
}
// Mark all read
if (isset($_GET['readall'])) {
    $pdo->query("UPDATE contact_messages SET is_read=1");
    flash('success','All messages marked as read.');
    redirect(BASE_URL.'pages/admin/messages.php');
}

$filter = sanitize($_GET['filter']??'all');
$where  = $filter==='unread' ? "WHERE is_read=0" : ($filter==='read' ? "WHERE is_read=1" : "WHERE 1=1");
$msgs   = $pdo->query("SELECT * FROM contact_messages $where ORDER BY created_at DESC")->fetchAll();
$unread = $pdo->query("SELECT COUNT(*) FROM contact_messages WHERE is_read=0")->fetchColumn();

$current = null;
if (isset($_GET['id'])) {
    $s = $pdo->prepare("SELECT * FROM contact_messages WHERE id=?");
    $s->execute([(int)$_GET['id']]); $current = $s->fetch();
    if ($current && !$current['is_read']) {
        $pdo->prepare("UPDATE contact_messages SET is_read=1 WHERE id=?")->execute([$current['id']]);
    }
}

admin_header('Contact Messages');
?>
<div style="display:flex;gap:1.5rem;height:calc(100vh - 160px)">
  <!-- INBOX LIST -->
  <div style="width:340px;flex-shrink:0;background:#fff;border-radius:10px;box-shadow:0 2px 12px rgba(0,0,0,.06);display:flex;flex-direction:column;overflow:hidden">
    <div style="padding:.9rem 1.1rem;border-bottom:1px solid #f0f0f0;display:flex;gap:.4rem;flex-wrap:wrap;align-items:center;justify-content:space-between">
      <div style="display:flex;gap:.4rem">
        <?php foreach(['all'=>'All','unread'=>'Unread','read'=>'Read'] as $k=>$l): ?>
        <a href="?filter=<?=$k?>" style="padding:.28rem .8rem;border-radius:20px;font-size:.75rem;font-weight:600;border:1px solid <?=$filter===$k?'#27ae60':'#e0e0e0'?>;background:<?=$filter===$k?'#27ae60':'#fff'?>;color:<?=$filter===$k?'#fff':'#666'?>;transition:all .2s"><?=$l?> <?=$k==='unread'&&$unread?'('.$unread.')':''?></a>
        <?php endforeach; ?>
      </div>
      <?php if($unread>0): ?>
      <a href="?readall=1" style="font-size:.72rem;color:#27ae60;font-weight:600" onclick="return confirm('Mark all as read?')">Mark all read</a>
      <?php endif; ?>
    </div>
    <div style="overflow-y:auto;flex:1">
      <?php if(empty($msgs)): ?>
      <div style="padding:2rem;text-align:center;color:#aaa;font-size:.85rem">No messages.</div>
      <?php else: ?>
      <?php foreach($msgs as $m):
        $sel = isset($_GET['id']) && (int)$_GET['id']===$m['id'];
      ?>
      <a href="?id=<?=$m['id']?>&filter=<?=$filter?>" style="display:block;padding:.9rem 1.1rem;border-bottom:1px solid #f8f8f8;transition:background .2s;background:<?=$sel?'#f0faf5':($m['is_read']?'#fff':'#fffbf0')?>;position:relative;text-decoration:none;border-left:<?=$sel?'3px solid #27ae60':'3px solid transparent'?>">
        <div style="display:flex;justify-content:space-between;font-size:.72rem;color:#aaa;margin-bottom:.2rem">
          <span><?=e($m['email'])?></span>
          <span><?=date('M d',strtotime($m['created_at']))?></span>
        </div>
        <div style="font-size:.87rem;font-weight:600;color:#1a1a2e;margin-bottom:.15rem"><?=e($m['name'])?></div>
        <div style="font-size:.78rem;color:#888;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:270px"><?=e(substr($m['subject']?:$m['message'],0,55))?></div>
        <?php if(!$m['is_read']): ?><div style="width:8px;height:8px;border-radius:50%;background:#27ae60;position:absolute;right:1rem;top:50%;transform:translateY(-50%)"></div><?php endif; ?>
      </a>
      <?php endforeach; ?>
      <?php endif; ?>
    </div>
  </div>

  <!-- MESSAGE VIEW -->
  <div style="flex:1;background:#fff;border-radius:10px;box-shadow:0 2px 12px rgba(0,0,0,.06);padding:2rem;overflow-y:auto">
    <?php if($current): ?>
    <div style="border-bottom:1px solid #f0f0f0;padding-bottom:1.2rem;margin-bottom:1.5rem">
      <h2 style="font-family:'Playfair Display',serif;font-size:1.4rem;color:#1a1a2e;margin-bottom:.6rem"><?=e($current['subject']??'(No Subject)')?></h2>
      <div style="display:flex;align-items:center;gap:.8rem">
        <div style="width:42px;height:42px;border-radius:50%;background:#27ae60;color:#fff;display:flex;align-items:center;justify-content:center;font-weight:700;flex-shrink:0"><?=strtoupper(substr($current['name'],0,2))?></div>
        <div>
          <strong style="display:block;color:#1a1a2e"><?=e($current['name'])?></strong>
          <small style="color:#888"><?=e($current['email'])?> &middot; <?=date('M j, Y \a\t g:i A',strtotime($current['created_at']))?></small>
        </div>
      </div>
    </div>
    <div style="background:#f9f9f9;border-radius:8px;padding:1.4rem;color:#555;line-height:1.9;font-size:.92rem;margin-bottom:1.5rem;white-space:pre-wrap"><?=nl2br(e($current['message']))?></div>
    <div style="display:flex;gap:.8rem;flex-wrap:wrap">
      <a href="mailto:<?=e($current['email'])?>" style="background:#27ae60;color:#fff;padding:.62rem 1.3rem;border-radius:6px;font-weight:600;font-size:.85rem;display:inline-flex;align-items:center;gap:.5rem"><i class="fas fa-reply"></i> Reply via Email</a>
      <?php if($_SESSION['role']==='admin'): ?>
      <a href="?delete=<?=$current['id']?>&filter=<?=$filter?>" onclick="return confirm('Delete this message?')" style="background:#f8d7da;color:#721c24;padding:.62rem 1.3rem;border-radius:6px;font-weight:600;font-size:.85rem;display:inline-flex;align-items:center;gap:.5rem"><i class="fas fa-trash"></i> Delete</a>
      <?php endif; ?>
    </div>
    <?php else: ?>
    <div style="display:flex;flex-direction:column;align-items:center;justify-content:center;height:100%;color:#aaa;text-align:center">
      <i class="fas fa-inbox" style="font-size:3rem;color:#ddd;display:block;margin-bottom:.8rem"></i>
      <p>Select a message to read</p>
    </div>
    <?php endif; ?>
  </div>
</div>
<?php admin_footer(); ?>
