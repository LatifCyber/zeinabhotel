<?php
require_once __DIR__.'/../includes/config.php';
require_once __DIR__.'/../includes/layout.php';

$checkin  = sanitize($_GET['checkin']  ?? date('Y-m-d'));
$checkout = sanitize($_GET['checkout'] ?? date('Y-m-d', strtotime('+1 day')));
$type     = sanitize($_GET['type']     ?? '');
$guests   = (int)($_GET['guests'] ?? 0);

// Build query
$sql = "SELECT r.id AS room_id, r.room_number, r.floor, rt.id AS type_id, rt.name, rt.description, rt.price, rt.capacity, rt.size_sqm, rt.amenities, rt.image_url
        FROM rooms r
        JOIN room_types rt ON r.type_id=rt.id
        WHERE r.status='available'
          AND r.id NOT IN (
            SELECT room_id FROM bookings
            WHERE status NOT IN ('cancelled','checked_out')
              AND check_in < ? AND check_out > ?
          )";
$params = [$checkout, $checkin];
if ($type)   { $sql .= " AND rt.name LIKE ?"; $params[] = "%$type%"; }
if ($guests) { $sql .= " AND rt.capacity >= ?"; $params[] = $guests; }
$sql .= " ORDER BY rt.price ASC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rooms = $stmt->fetchAll();

$roomTypes = $pdo->query("SELECT DISTINCT name FROM room_types ORDER BY price")->fetchAll(PDO::FETCH_COLUMN);

include_header('Rooms', 'rooms');
?>
<section class="page-hero" style="background:url('https://images.unsplash.com/photo-1631049307264-da0ec9d70304?w=1400')center/cover;padding-top:70px">
  <div class="page-hero-content">
    <h1>Our Rooms</h1>
    <p class="breadcrumb"><a href="<?=BASE_URL?>index.php">Home</a> / <span>Rooms</span></p>
  </div>
</section>

<section style="padding:4rem 0;background:#f7f9f7">
  <div class="container">
    <!-- FILTER BAR -->
    <form method="GET" style="background:#fff;border-radius:10px;padding:1.3rem 1.5rem;margin-bottom:2rem;box-shadow:0 2px 12px rgba(0,0,0,.07);display:flex;gap:1rem;flex-wrap:wrap;align-items:flex-end">
      <div style="flex:1;min-width:140px">
        <label style="display:block;font-size:.72rem;font-weight:600;text-transform:uppercase;letter-spacing:1px;color:#888;margin-bottom:.3rem"><i class="fas fa-calendar-check" style="color:#27ae60"></i> Check In</label>
        <input type="date" name="checkin" value="<?=e($checkin)?>" style="border:1px solid #e0e0e0;border-radius:6px;padding:.6rem .9rem;font-size:.88rem;width:100%;outline:none"/>
      </div>
      <div style="flex:1;min-width:140px">
        <label style="display:block;font-size:.72rem;font-weight:600;text-transform:uppercase;letter-spacing:1px;color:#888;margin-bottom:.3rem"><i class="fas fa-calendar-times" style="color:#27ae60"></i> Check Out</label>
        <input type="date" name="checkout" value="<?=e($checkout)?>" style="border:1px solid #e0e0e0;border-radius:6px;padding:.6rem .9rem;font-size:.88rem;width:100%;outline:none"/>
      </div>
      <div style="flex:1;min-width:130px">
        <label style="display:block;font-size:.72rem;font-weight:600;text-transform:uppercase;letter-spacing:1px;color:#888;margin-bottom:.3rem"><i class="fas fa-bed" style="color:#27ae60"></i> Room Type</label>
        <select name="type" style="border:1px solid #e0e0e0;border-radius:6px;padding:.6rem .9rem;font-size:.88rem;width:100%;outline:none">
          <option value="">All Types</option>
          <?php foreach($roomTypes as $rt): ?>
          <option value="<?=e($rt)?>" <?=$type===$rt?'selected':''?>><?=e($rt)?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div style="flex:1;min-width:110px">
        <label style="display:block;font-size:.72rem;font-weight:600;text-transform:uppercase;letter-spacing:1px;color:#888;margin-bottom:.3rem"><i class="fas fa-users" style="color:#27ae60"></i> Guests</label>
        <select name="guests" style="border:1px solid #e0e0e0;border-radius:6px;padding:.6rem .9rem;font-size:.88rem;width:100%;outline:none">
          <option value="">Any</option>
          <option value="1" <?=$guests===1?'selected':''?>>1+</option>
          <option value="2" <?=$guests===2?'selected':''?>>2+</option>
          <option value="3" <?=$guests===3?'selected':''?>>3+</option>
          <option value="4" <?=$guests===4?'selected':''?>>4+</option>
        </select>
      </div>
      <button type="submit" class="btn-sm" style="padding:.68rem 1.8rem"><i class="fas fa-search"></i> Search</button>
    </form>

    <p style="color:#888;font-size:.88rem;margin-bottom:1.5rem">Showing <strong style="color:#27ae60"><?=count($rooms)?></strong> available room<?=count($rooms)!==1?'s':''?></p>

    <div class="rooms-grid">
      <?php if(empty($rooms)): ?>
      <div style="grid-column:1/-1;text-align:center;padding:4rem;color:#aaa">
        <i class="fas fa-bed" style="font-size:3rem;color:#ddd;display:block;margin-bottom:1rem"></i>
        <p>No rooms available for the selected criteria. Try different dates.</p>
        <a href="<?=BASE_URL?>pages/rooms.php" style="color:#27ae60;font-weight:600;margin-top:.8rem;display:inline-block">Reset Filters</a>
      </div>
      <?php else: ?>
      <?php foreach($rooms as $r):
        $amenArr = array_map('trim', explode(',', $r['amenities']??''));
      ?>
      <div class="room-card" data-aos>
        <div class="room-img" style="background:url('<?=e($r['image_url'])?>') center/cover"></div>
        <div class="room-badge"><?=e($r['name'])?></div>
        <div class="room-info">
          <h3>Room <?=e($r['room_number'])?> – <?=e($r['name'])?></h3>
          <div class="room-meta">
            <span><i class="fas fa-users"></i> <?=$r['capacity']?> Guests</span>
            <span><i class="fas fa-expand"></i> <?=$r['size_sqm']?>m²</span>
            <span><i class="fas fa-layer-group"></i> Floor <?=$r['floor']===0?'G':$r['floor']?></span>
          </div>
          <div style="display:flex;flex-wrap:wrap;gap:.4rem;margin-bottom:1rem">
            <?php foreach(array_slice($amenArr,0,4) as $a): ?>
            <span style="background:#f0faf5;color:#27ae60;font-size:.72rem;padding:.22rem .65rem;border-radius:20px;font-weight:500"><?=e(trim($a))?></span>
            <?php endforeach; ?>
          </div>
          <div class="room-footer">
            <span class="price"><?=fmtCur($r['price'])?><sub>/night</sub></span>
            <a href="<?=BASE_URL?>pages/booking.php?room_id=<?=$r['room_id']?>&checkin=<?=e($checkin)?>&checkout=<?=e($checkout)?>" class="btn-book">Book Now</a>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
      <?php endif; ?>
    </div>
  </div>
</section>

<?php include_footer(); ?>
