<?php
require_once __DIR__.'/../includes/config.php';
require_once __DIR__.'/../includes/layout.php';
include_header('Facilities','facilities');
$facs=[
  ['Swimming Pool',    'fa-swimming-pool', 'https://images.unsplash.com/photo-1571902943202-507ec2618e8f?w=600','Olympic-size outdoor pool with sun loungers and a poolside bar. Open daily.','6:00 AM – 10:00 PM','Outdoor'],
  ['Fitness Center',  'fa-dumbbell',      'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=600','Fully equipped gym with cardio, free weights and personal training on request.','Open 24 Hours','24/7'],
  ['Restaurant & Bar','fa-utensils',      'https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=600','Award-winning restaurant serving international cuisine with locally sourced ingredients.','6–10 AM · 6–11 PM','Dining'],
  ['Spa & Wellness',  'fa-spa',           'https://images.unsplash.com/photo-1540497077202-7c8a3999166f?w=600','Full-service spa with massages, facials, sauna and steam rooms by certified therapists.','9:00 AM – 8:00 PM','Wellness'],
  ['Conference Rooms','fa-chalkboard-teacher','https://images.unsplash.com/photo-1497366216548-37526070297c?w=600','Modern rooms with AV equipment, high-speed internet and catering for up to 150 people.','8:00 AM – 10:00 PM','Business'],
  ['Airport Shuttle', 'fa-shuttle-van',   'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=600','Complimentary scheduled airport pick-up and drop-off with air-conditioned vehicles.','Every 2 Hours','Transport'],
  ['Tour & Excursions','fa-map-marked-alt','https://images.unsplash.com/photo-1521791136064-7986c2920216?w=600','Daily city tours, cultural visits, beach trips and adventure packages for all interests.','Daily Departures','Tours'],
  ['Free Wi-Fi',      'fa-wifi',          'https://images.unsplash.com/photo-1544197150-b99a580bb7a8?w=600','Fibre-optic Wi-Fi up to 300 Mbps throughout all rooms, common areas, pool and restaurant.','Available 24/7','Connectivity'],
  ['Laundry Service', 'fa-soap',          'https://images.unsplash.com/photo-1545558014-8692077e9b5c?w=600','Express same-day laundry, dry cleaning and ironing. Drop before 9 AM, collect by 6 PM.','7:00 AM – 9:00 PM','Service'],
];
?>
<section class="page-hero" style="background:url('https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=1400')center/cover;padding-top:70px">
  <div class="page-hero-content"><h1>Our Facilities</h1><p class="breadcrumb"><a href="<?=BASE_URL?>index.php">Home</a> / <span>Facilities</span></p></div>
</section>
<section style="padding:5rem 0;background:#f7f9f7">
  <div class="container">
    <div class="section-header">
      <p class="section-tag">Everything You Need</p>
      <h2 class="section-title">World-Class <span>Amenities</span></h2>
      <div class="divider"></div>
    </div>
    <div class="fac-grid" style="margin-top:3rem">
      <?php foreach($facs as $f): ?>
      <div class="fac-card" data-aos>
        <div class="fac-img" style="background:url('<?=$f[2]?>') center/cover">
          <div class="fac-overlay"></div>
          <div style="position:absolute;top:1rem;right:1rem;background:rgba(255,255,255,.15);backdrop-filter:blur(8px);color:#fff;padding:.28rem .75rem;border-radius:20px;font-size:.72rem;font-weight:600;border:1px solid rgba(255,255,255,.25)"><?=$f[5]?></div>
        </div>
        <div class="fac-body">
          <div class="fac-icon"><i class="fas <?=$f[1]?>"></i></div>
          <h3><?=$f[0]?></h3>
          <p><?=$f[3]?></p>
          <div class="fac-hours"><i class="fas fa-clock" style="margin-right:.4rem"></i><?=$f[4]?></div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php include_footer(); ?>
