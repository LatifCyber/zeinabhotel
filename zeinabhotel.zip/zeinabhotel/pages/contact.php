<?php
require_once __DIR__.'/../includes/config.php';
require_once __DIR__.'/../includes/layout.php';

// Handle form
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $name    = sanitize(($_POST['first_name']??'').' '.($_POST['last_name']??''));
    $email   = sanitize($_POST['email']??'');
    $subject = sanitize($_POST['subject']??'');
    $message = sanitize($_POST['message']??'');
    if (!$name || !$email || !$message) { flash('error','Please fill all required fields.'); }
    elseif (!filter_var($email,FILTER_VALIDATE_EMAIL)) { flash('error','Invalid email address.'); }
    else {
        $pdo->prepare("INSERT INTO contact_messages (name,email,subject,message) VALUES (?,?,?,?)")->execute([$name,$email,$subject,$message]);
        flash('success','Message sent! We\'ll get back to you within 24 hours.');
    }
    redirect(BASE_URL.'pages/contact.php');
}
$flash = getFlash();
include_header('Contact Us', 'contact');
?>
<section class="page-hero" style="background:url('https://images.unsplash.com/photo-1596394516093-501ba68a0ba6?w=1400')center/cover;padding-top:70px">
  <div class="page-hero-content">
    <h1>Get In Touch</h1>
    <p class="breadcrumb"><a href="<?=BASE_URL?>index.php">Home</a> / <span>Contact</span></p>
  </div>
</section>

<section style="padding:5rem 0;background:#f7f9f7">
  <div class="container">
    <div class="section-header">
      <p class="section-tag">Reach Out</p>
      <h2 class="section-title">We'd Love to <span>Hear From You</span></h2>
      <div class="divider"></div>
    </div>
    <div class="contact-layout" style="margin-top:3rem">
      <!-- INFO -->
      <div>
        <h3 style="font-family:'Playfair Display',serif;font-size:1.6rem;color:#1a1a2e;margin-bottom:1rem">Contact Information</h3>
        <p style="color:#888;line-height:1.8;margin-bottom:2rem">Have questions about your booking or need help planning your stay? Our team is available 24/7.</p>
        <?php foreach([
          ['fa-map-marker-alt','Address',    '21 Liberty Street, Ring Road Central<br/>Accra, Greater Accra, Ghana'],
          ['fa-phone-alt',     'Phone',      '+233 30 222 5555 (Main)<br/>+233 24 000 1234 (Reservations)'],
          ['fa-envelope',      'Email',      'info@hbms.com<br/>reservations@hbms.com'],
          ['fa-clock',         'Hours',      'Reception: Open 24/7<br/>Reservations: Mon–Sun 8am–10pm'],
        ] as [$icon,$title,$text]): ?>
        <div class="cinfo-item">
          <div class="cinfo-icon"><i class="fas <?=$icon?>"></i></div>
          <div class="cinfo-text"><h4><?=$title?></h4><p><?=$text?></p></div>
        </div>
        <?php endforeach; ?>
      </div>

      <!-- FORM -->
      <div class="cf-box">
        <h3>Send Us a Message</h3>
        <p>Fill out the form and we'll respond within 24 hours.</p>

        <?php if($flash): ?>
        <div class="inline-flash <?=$flash['type']==='success'?'if-success':'if-error'?>" style="margin-bottom:1rem">
          <i class="fas fa-<?=$flash['type']==='success'?'check-circle':'exclamation-circle'?>"></i> <?=e($flash['msg'])?>
        </div>
        <?php endif; ?>

        <form method="POST" action="<?=BASE_URL?>pages/contact.php">
          <div class="form-row-2" style="gap:1rem">
            <div class="cffg"><label>First Name *</label><input type="text" name="first_name" placeholder="John" required/></div>
            <div class="cffg"><label>Last Name *</label><input type="text" name="last_name" placeholder="Doe" required/></div>
          </div>
          <div class="form-row-2" style="gap:1rem">
            <div class="cffg"><label>Email *</label><input type="email" name="email" placeholder="you@example.com" required/></div>
            <div class="cffg"><label>Phone</label><input type="tel" name="phone" placeholder="+233 20 000 0000"/></div>
          </div>
          <div class="cffg">
            <label>Subject</label>
            <select name="subject">
              <option value="">Select a subject</option>
              <option>Reservation Inquiry</option>
              <option>Room Information</option>
              <option>Pricing &amp; Packages</option>
              <option>Group Booking</option>
              <option>Complaint / Feedback</option>
              <option>Other</option>
            </select>
          </div>
          <div class="cffg"><label>Message *</label><textarea name="message" placeholder="Write your message here..." required></textarea></div>
          <button type="submit" class="btn-send"><i class="fas fa-paper-plane"></i> &nbsp;Send Message</button>
        </form>
      </div>
    </div>
  </div>
</section>

<!-- MAP -->
<div style="height:300px;overflow:hidden">
  <iframe src="https://maps.google.com/maps?q=Accra+Ghana&output=embed" width="100%" height="300" style="border:none;filter:grayscale(20%)" loading="lazy"></iframe>
</div>

<?php include_footer(); ?>
