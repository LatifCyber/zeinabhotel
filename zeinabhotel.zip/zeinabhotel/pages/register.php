<?php
require_once __DIR__.'/../includes/config.php';
if (isLoggedIn()) redirect(BASE_URL.'pages/dashboard.php');
$flash = getFlash();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<title>Register – HBMS</title>
<link rel="stylesheet" href="<?=BASE_URL?>css/style.css"/>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Jost:wght@300;400;500;600&display=swap" rel="stylesheet"/>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>
</head>
<body>
<div class="auth-wrap">
  <div class="auth-visual" style="background:url('https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?w=900')center/cover">
    <div class="auth-visual-content">
      <h2>Join HBMS Today</h2>
      <p>Create your account and unlock exclusive access to room bookings, special deals, and premium guest services.</p>
    </div>
  </div>
  <div class="auth-form-side">
    <div class="auth-logo"><a href="<?=BASE_URL?>index.php" style="color:inherit"><span>H</span>BMS</a></div>
    <h2 class="auth-title">Create Account</h2>
    <p class="auth-sub">Fill the form below to get started</p>

    <?php if($flash): ?>
    <div class="inline-flash <?=$flash['type']==='success'?'if-success':'if-error'?>">
      <i class="fas fa-<?=$flash['type']==='success'?'check-circle':'exclamation-circle'?>"></i> <?=e($flash['msg'])?>
    </div>
    <?php endif; ?>

    <form action="<?=BASE_URL?>php/auth.php?action=register" method="POST" id="regForm">
      <div class="form-row-2">
        <div class="form-group">
          <label>Full Name *</label>
          <div class="input-wrap">
            <i class="fas fa-user input-icon"></i>
            <input type="text" name="name" placeholder="John Doe" required/>
          </div>
        </div>
        <div class="form-group">
          <label>Phone Number</label>
          <div class="input-wrap">
            <i class="fas fa-phone input-icon"></i>
            <input type="tel" name="phone" placeholder="+233 20 000 0000"/>
          </div>
        </div>
      </div>
      <div class="form-group">
        <label>Email Address *</label>
        <div class="input-wrap">
          <i class="fas fa-envelope input-icon"></i>
          <input type="email" name="email" placeholder="you@example.com" required/>
        </div>
      </div>
      <div class="form-group">
        <label>Password *</label>
        <div class="input-wrap">
          <i class="fas fa-lock input-icon"></i>
          <input type="password" name="password" id="pwd" placeholder="Minimum 6 characters" required oninput="checkStrength(this.value)"/>
          <button type="button" class="input-eye" onclick="togglePwd('pwd','eye1')"><i class="fas fa-eye" id="eye1"></i></button>
        </div>
        <div class="pw-bar" id="pwBar"></div>
      </div>
      <div class="form-group">
        <label>Confirm Password *</label>
        <div class="input-wrap">
          <i class="fas fa-lock input-icon"></i>
          <input type="password" name="confirm" id="cpwd" placeholder="Re-enter your password" required/>
          <button type="button" class="input-eye" onclick="togglePwd('cpwd','eye2')"><i class="fas fa-eye" id="eye2"></i></button>
        </div>
      </div>
      <button type="submit" class="btn-submit"><i class="fas fa-user-plus"></i> &nbsp;Create Account</button>
    </form>
    <div class="auth-divider">or</div>
    <p class="auth-switch">Already have an account? <a href="<?=BASE_URL?>pages/login.php">Sign in</a></p>
    <p class="auth-switch" style="margin-top:.5rem"><a href="<?=BASE_URL?>index.php"><i class="fas fa-arrow-left"></i> Back to Home</a></p>
  </div>
</div>
<script>
function togglePwd(id,eid){const p=document.getElementById(id);const e=document.getElementById(eid);p.type=p.type==='password'?'text':'password';e.className='fas fa-'+(p.type==='text'?'eye-slash':'eye');}
function checkStrength(v){const b=document.getElementById('pwBar');let s=0;if(v.length>=6)s++;if(/[A-Z]/.test(v))s++;if(/[0-9]/.test(v))s++;if(/[^A-Za-z0-9]/.test(v))s++;const c=['#e74c3c','#e67e22','#f1c40f','#27ae60'];b.style.width=(s*25)+'%';b.style.background=c[s-1]||'rgba(255,255,255,.1)';}
document.getElementById('regForm').addEventListener('submit',function(e){
  const p=document.getElementById('pwd').value;
  const c=document.getElementById('cpwd').value;
  if(p!==c){e.preventDefault();alert('Passwords do not match!');}
});
</script>
</body>
</html>
