<?php
require_once __DIR__.'/../includes/config.php';
require_once __DIR__.'/../includes/layout.php';
requireLogin();

$uid = $_SESSION['user_id'];
$user = $pdo->prepare("SELECT * FROM users WHERE id=?");
$user->execute([$uid]); $user = $user->fetch();

$bookings = $pdo->prepare("
  SELECT b.*, r.room_number, rt.name AS room_type, rt.image_url
  FROM bookings b
  JOIN rooms r ON b.room_id=r.id
  JOIN room_types rt ON r.type_id=rt.id
  WHERE b.user_id=? ORDER BY b.created_at DESC
");
$bookings->execute([$uid]); $bookings = $bookings->fetchAll();

$totalBookings = count($bookings);
$upcoming      = count(array_filter($bookings, fn($b)=>in_array($b['status'],['pending','confirmed'])));
$totalSpent    = array_sum(array_column(array_filter($bookings,fn($b)=>$b['payment_status']==='paid'),'total_amount'));

// Handle cancel from this page
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['cancel_booking'])) {
    $bid = (int)$_POST['booking_id'];
    $pdo->prepare("UPDATE bookings SET status='cancelled' WHERE id=? AND user_id=? AND status='pending'")->execute([$bid,$uid]);
    flash('success','Booking cancelled successfully.');
    redirect(BASE_URL.'pages/dashboard.php');
}
$flash = getFlash();

include_header('My Dashboard');
?>
<div style="margin-top:70px"></div>
<div class="dash-layout">
  <!-- SIDEBAR -->
  <aside class="dash-sidebar">
    <div class="dash-logo"><a href="<?=BASE_URL?>index.php" style="color:inherit"><span>H</span>BMS</a></div>
    <div class="dash-user-box">
      <div class="d-avatar"><?=strtoupper(substr($user['name'],0,2))?></div>
      <div class="d-avatar-name">
        <strong><?=e($user['name'])?></strong>
        <small>Guest Account</small>
      </div>
    </div>
    <nav class="dash-nav">
      <div class="nav-section">Menu</div>
      <a href="<?=BASE_URL?>pages/dashboard.php" class="active"><i class="fas fa-th-large"></i> Dashboard</a>
      <a href="<?=BASE_URL?>pages/rooms.php"><i class="fas fa-bed"></i> Browse Rooms</a>
      <a href="<?=BASE_URL?>pages/booking.php"><i class="fas fa-calendar-plus"></i> New Booking</a>
      <div class="nav-section">Account</div>
      <a href="<?=BASE_URL?>pages/contact.php"><i class="fas fa-envelope"></i> Contact Support</a>
      <a href="<?=BASE_URL?>php/auth.php?action=logout"><i class="fas fa-sign-out-alt"></i> Sign Out</a>
    </nav>
  </aside>

  <!-- MAIN -->
  <div class="dash-main">
    <div class="dash-topbar">
      <h1>Welcome, <?=e(explode(' ',$user['name'])[0])?> 👋</h1>
      <a href="<?=BASE_URL?>pages/booking.php" class="btn-sm"><i class="fas fa-plus"></i> New Booking</a>
    </div>
    <div class="dash-content">
      <?php if($flash): ?>
      <div class="d-flash <?=$flash['type']?>"><?=e($flash['msg'])?></div>
      <?php endif; ?>

      <!-- STATS -->
      <div class="stats-row">
        <div class="s-card"><div class="s-icon" style="background:#e8f5ee"><i class="fas fa-calendar-check" style="color:#27ae60"></i></div><div class="s-body"><p>Total Bookings</p><h3><?=$totalBookings?></h3></div></div>
        <div class="s-card"><div class="s-icon" style="background:#fff3cd"><i class="fas fa-clock" style="color:#f57f17"></i></div><div class="s-body"><p>Upcoming</p><h3><?=$upcoming?></h3></div></div>
        <div class="s-card"><div class="s-icon" style="background:#e0f2f1"><i class="fas fa-dollar-sign" style="color:#009688"></i></div><div class="s-body"><p>Total Spent</p><h3><?=fmtCur($totalSpent)?></h3></div></div>
        <div class="s-card"><div class="s-icon" style="background:#f3e5f5"><i class="fas fa-star" style="color:#9c27b0"></i></div><div class="s-body"><p>Reviews</p><h3><?=$pdo->prepare("SELECT COUNT(*) FROM reviews WHERE user_id=?")->execute([$uid])||0?><?=$pdo->prepare("SELECT COUNT(*) FROM reviews WHERE user_id=?")->execute([$uid])?$pdo->query("SELECT COUNT(*) FROM reviews WHERE user_id=$uid")->fetchColumn():0?></h3></div></div>
      </div>

      <!-- BOOKINGS TABLE -->
      <div class="d-card">
        <div class="d-card-header">
          <h3><i class="fas fa-list" style="color:#27ae60;margin-right:.4rem"></i> My Bookings</h3>
          <a href="<?=BASE_URL?>pages/booking.php">+ New Booking</a>
        </div>
        <?php if(empty($bookings)): ?>
        <div style="text-align:center;padding:3rem;color:#aaa">
          <i class="fas fa-bed" style="font-size:2.5rem;color:#ddd;display:block;margin-bottom:.8rem"></i>
          <p>No bookings yet. <a href="<?=BASE_URL?>pages/rooms.php" style="color:#27ae60;font-weight:600">Browse rooms</a> to get started.</p>
        </div>
        <?php else: ?>
        <div class="tbl-wrap">
          <table class="d-table">
            <thead>
              <tr><th>Ref #</th><th>Room</th><th>Check-In</th><th>Check-Out</th><th>Nights</th><th>Amount</th><th>Status</th><th>Payment</th><th>Action</th></tr>
            </thead>
            <tbody>
              <?php foreach($bookings as $b):
                $n = nights($b['check_in'],$b['check_out']);
              ?>
              <tr>
                <td><strong><?=e($b['booking_ref'])?></strong></td>
                <td><?=e($b['room_number'])?> – <?=e($b['room_type'])?></td>
                <td><?=fmtDate($b['check_in'])?></td>
                <td><?=fmtDate($b['check_out'])?></td>
                <td><?=$n?></td>
                <td><strong><?=fmtCur($b['total_amount'])?></strong></td>
                <td><span class="sb sb-<?=$b['status']?>"><?=ucfirst(str_replace('_',' ',$b['status']))?></span></td>
                <td><span class="sb sb-<?=$b['payment_status']?>"><?=ucfirst($b['payment_status'])?></span></td>
                <td>
                  <?php if($b['status']==='pending'): ?>
                  <form method="POST" onsubmit="return confirm('Cancel this booking?')">
                    <input type="hidden" name="booking_id" value="<?=$b['id']?>"/>
                    <button type="submit" name="cancel_booking" class="btn-sm-red">Cancel</button>
                  </form>
                  <?php else: ?>
                  <span style="color:#aaa;font-size:.78rem">—</span>
                  <?php endif; ?>
                </td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>
<?php include_footer(); ?>
