<?php
require_once __DIR__.'/../includes/config.php';
require_once __DIR__.'/../includes/layout.php';

requireLogin();

$ref = sanitize($_GET['ref'] ?? '');
if (!$ref) { flash('error','Invalid receipt reference.'); redirect(BASE_URL.'pages/dashboard.php'); }

// Fetch booking with full details
$stmt = $pdo->prepare("
    SELECT b.*,
           u.name AS guest_name, u.email AS guest_email, u.phone AS guest_phone,
           r.room_number, rt.name AS room_type, rt.price AS price_per_night,
           rt.amenities, rt.image_url
    FROM bookings b
    JOIN users u  ON b.user_id = u.id
    JOIN rooms r  ON b.room_id = r.id
    JOIN room_types rt ON r.type_id = rt.id
    WHERE b.booking_ref = ?
");
$stmt->execute([$ref]);
$b = $stmt->fetch();

if (!$b) { flash('error','Booking not found.'); redirect(BASE_URL.'pages/dashboard.php'); }

// Only allow the booking owner or admin/staff to view
if ($_SESSION['user_id'] != $b['user_id'] && !in_array($_SESSION['role'] ?? '', ['admin','staff'])) {
    flash('error','Access denied.'); redirect(BASE_URL.'pages/dashboard.php');
}

$nights   = (new DateTime($b['check_in']))->diff(new DateTime($b['check_out']))->days;
$subtotal = $b['price_per_night'] * $nights;
$tax      = $subtotal * 0.10;
$total    = $subtotal + $tax;

$statusColors = [
    'pending'     => ['bg'=>'#fff3cd','color'=>'#856404','label'=>'Pending'],
    'confirmed'   => ['bg'=>'#d1ecf1','color'=>'#0c5460','label'=>'Confirmed'],
    'checked_in'  => ['bg'=>'#d4edda','color'=>'#155724','label'=>'Checked In'],
    'checked_out' => ['bg'=>'#e2e3e5','color'=>'#383d41','label'=>'Checked Out'],
    'cancelled'   => ['bg'=>'#f8d7da','color'=>'#721c24','label'=>'Cancelled'],
];
$payColors = [
    'unpaid'   => ['bg'=>'#f8d7da','color'=>'#721c24','label'=>'Unpaid'],
    'paid'     => ['bg'=>'#d4edda','color'=>'#155724','label'=>'Paid'],
    'refunded' => ['bg'=>'#e2e3e5','color'=>'#383d41','label'=>'Refunded'],
];

$sc = $statusColors[$b['status']] ?? $statusColors['pending'];
$pc = $payColors[$b['payment_status']] ?? $payColors['unpaid'];

$amenitiesList = explode(',', $b['amenities'] ?? '');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>Receipt – <?=e($ref)?> | HBMS</title>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet"/>
<style>
/* ── Base ─────────────────────────────────────────────── */
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Inter',sans-serif;background:#f0f2f0;color:#1a1a2e;font-size:14px}

/* ── Screen toolbar ───────────────────────────────────── */
.toolbar{background:#1a1a2e;color:#fff;padding:1rem 2rem;display:flex;align-items:center;justify-content:space-between;gap:1rem;flex-wrap:wrap}
.toolbar h2{font-family:'Playfair Display',serif;font-size:1.2rem;color:#fff}
.toolbar-btns{display:flex;gap:.7rem}
.btn{padding:.55rem 1.2rem;border-radius:6px;font-size:.85rem;font-weight:600;cursor:pointer;border:none;display:inline-flex;align-items:center;gap:.4rem;text-decoration:none;transition:opacity .2s}
.btn-print{background:#27ae60;color:#fff}
.btn-back {background:rgba(255,255,255,.15);color:#fff}
.btn:hover{opacity:.88}

/* ── Receipt card ─────────────────────────────────────── */
.receipt-wrap{max-width:800px;margin:2rem auto;padding:0 1rem 3rem}
.receipt{background:#fff;border-radius:12px;box-shadow:0 4px 24px rgba(0,0,0,.10);overflow:hidden}

/* ── Header ───────────────────────────────────────────── */
.rec-header{background:linear-gradient(135deg,#1a1a2e 0%,#16213e 60%,#0f3460 100%);color:#fff;padding:2.5rem 2.5rem 2rem;display:flex;justify-content:space-between;align-items:flex-start;gap:1.5rem;flex-wrap:wrap}
.hotel-brand .brand-name{font-family:'Playfair Display',serif;font-size:1.9rem;letter-spacing:.5px}
.hotel-brand .brand-tag{font-size:.78rem;color:#a0aec0;margin-top:.2rem;letter-spacing:1px;text-transform:uppercase}
.hotel-brand .brand-address{font-size:.8rem;color:#cbd5e0;margin-top:.6rem;line-height:1.6}
.rec-ref{text-align:right}
.rec-ref .ref-label{font-size:.72rem;color:#a0aec0;letter-spacing:1px;text-transform:uppercase}
.rec-ref .ref-code{font-size:1.5rem;font-weight:700;letter-spacing:1px;color:#fff;margin:.2rem 0}
.rec-ref .ref-date{font-size:.78rem;color:#a0aec0}
.rec-ref .status-badge{display:inline-block;padding:.3rem .8rem;border-radius:20px;font-size:.75rem;font-weight:600;margin-top:.5rem}

/* ── Room banner ──────────────────────────────────────── */
.room-banner{height:180px;background:url('<?=e($b['image_url'])?>') center/cover no-repeat;position:relative}
.room-banner::after{content:'';position:absolute;inset:0;background:linear-gradient(to right,rgba(0,0,0,.55) 0%,rgba(0,0,0,.1) 100%)}
.room-banner-info{position:absolute;bottom:1.2rem;left:1.8rem;color:#fff;z-index:1}
.room-banner-info h3{font-family:'Playfair Display',serif;font-size:1.3rem}
.room-banner-info p{font-size:.8rem;opacity:.85;margin-top:.2rem}

/* ── Body ─────────────────────────────────────────────── */
.rec-body{padding:2rem 2.5rem}

/* ── Section headings ─────────────────────────────────── */
.sec-title{font-size:.7rem;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:#27ae60;border-bottom:2px solid #e8f5ee;padding-bottom:.4rem;margin-bottom:1rem}

/* ── Info grids ───────────────────────────────────────── */
.info-grid{display:grid;grid-template-columns:1fr 1fr;gap:.6rem 2rem;margin-bottom:1.6rem}
.info-grid.three{grid-template-columns:1fr 1fr 1fr}
.irow .lbl{font-size:.75rem;color:#888;margin-bottom:.15rem}
.irow .val{font-size:.9rem;font-weight:600;color:#1a1a2e}

/* ── Stay dates highlight ─────────────────────────────── */
.dates-row{display:grid;grid-template-columns:1fr auto 1fr;gap:1rem;align-items:center;background:#f7f9f7;border-radius:8px;padding:1.2rem;margin-bottom:1.6rem;text-align:center}
.dates-row .date-box .lbl{font-size:.72rem;color:#888;letter-spacing:.5px;text-transform:uppercase}
.dates-row .date-box .date{font-size:1.1rem;font-weight:700;color:#1a1a2e;margin:.2rem 0}
.dates-row .date-box .day{font-size:.78rem;color:#666}
.dates-arrow{display:flex;flex-direction:column;align-items:center;color:#27ae60}
.dates-arrow .nights{font-size:.75rem;font-weight:600;color:#27ae60;margin-top:.2rem}

/* ── Amenities ────────────────────────────────────────── */
.amenities-row{display:flex;flex-wrap:wrap;gap:.5rem;margin-bottom:1.6rem}
.amenity-tag{background:#e8f5ee;color:#1e8449;padding:.25rem .7rem;border-radius:20px;font-size:.75rem;font-weight:500}

/* ── Price table ──────────────────────────────────────── */
.price-table{width:100%;border-collapse:collapse;margin-bottom:.5rem}
.price-table tr td{padding:.55rem .5rem;font-size:.88rem}
.price-table tr td:last-child{text-align:right;font-weight:500}
.price-table .divider td{border-top:1px solid #e8e8e8}
.price-table .total-row td{font-size:1.05rem;font-weight:700;color:#1a1a2e;border-top:2px solid #1a1a2e;padding-top:.7rem}
.price-table .tax-row td{color:#888;font-size:.82rem}

/* ── Payment badge ────────────────────────────────────── */
.pay-badge{display:inline-flex;align-items:center;gap:.4rem;padding:.3rem .9rem;border-radius:20px;font-size:.8rem;font-weight:600;margin-bottom:1.6rem}

/* ── Special requests ─────────────────────────────────── */
.special-box{background:#fffdf0;border-left:3px solid #f0ad4e;padding:.8rem 1rem;border-radius:0 6px 6px 0;font-size:.85rem;color:#7d6608;line-height:1.6;margin-bottom:1.6rem}

/* ── Footer ───────────────────────────────────────────── */
.rec-footer{background:#f7f9f7;border-top:1px solid #e8e8e8;padding:1.5rem 2.5rem;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:1rem}
.rec-footer .thank-you{font-family:'Playfair Display',serif;font-size:1rem;color:#1a1a2e}
.rec-footer .help-text{font-size:.78rem;color:#888;margin-top:.2rem}
.rec-footer .barcode{font-size:.65rem;color:#bbb;letter-spacing:2px;font-family:monospace}

/* ── Divider ──────────────────────────────────────────── */
.divider-line{border:none;border-top:1px dashed #ddd;margin:1.4rem 0}

/* ══════════════════════════════════════════════════════ */
/* ── PRINT STYLES ─────────────────────────────────────── */
@media print {
  body{background:#fff;font-size:12px}
  .toolbar{display:none !important}
  .receipt-wrap{max-width:100%;margin:0;padding:0}
  .receipt{box-shadow:none;border-radius:0}
  .room-banner{height:130px}
  @page{margin:0;size:A4}
}
</style>
</head>
<body>

<!-- SCREEN TOOLBAR (hidden on print) -->
<div class="toolbar">
  <h2>📄 Booking Receipt</h2>
  <div class="toolbar-btns">
    <a href="<?=BASE_URL?>pages/dashboard.php" class="btn btn-back">← Back to Dashboard</a>
    <button class="btn btn-print" onclick="window.print()">🖨️ Print / Save PDF</button>
  </div>
</div>

<!-- RECEIPT -->
<div class="receipt-wrap">
<div class="receipt">

  <!-- HEADER -->
  <div class="rec-header">
    <div class="hotel-brand">
      <div class="brand-name">🏨 HBMS Hotel</div>
      <div class="brand-tag">Hotel &amp; Booking Management System</div>
      <div class="brand-address">
        123 Hospitality Avenue, Accra, Ghana<br>
        📞 +233 20 000 0000 &nbsp;|&nbsp; ✉️ info@hbms.com
      </div>
    </div>
    <div class="rec-ref">
      <div class="ref-label">Booking Reference</div>
      <div class="ref-code"><?=e($b['booking_ref'])?></div>
      <div class="ref-date">Booked: <?=date('d M Y, H:i', strtotime($b['created_at']))?></div>
      <div>
        <span class="status-badge" style="background:<?=$sc['bg']?>;color:<?=$sc['color']?>">
          ● <?=$sc['label']?>
        </span>
      </div>
    </div>
  </div>

  <!-- ROOM BANNER -->
  <?php if($b['image_url']): ?>
  <div class="room-banner">
    <div class="room-banner-info">
      <h3><?=e($b['room_type'])?></h3>
      <p>Room <?=e($b['room_number'])?></p>
    </div>
  </div>
  <?php endif; ?>

  <!-- BODY -->
  <div class="rec-body">

    <!-- GUEST DETAILS -->
    <div class="sec-title">Guest Information</div>
    <div class="info-grid three">
      <div class="irow"><div class="lbl">Full Name</div><div class="val"><?=e($b['guest_name'])?></div></div>
      <div class="irow"><div class="lbl">Email</div><div class="val"><?=e($b['guest_email'])?></div></div>
      <div class="irow"><div class="lbl">Phone</div><div class="val"><?=e($b['guest_phone'] ?: '—')?></div></div>
    </div>

    <hr class="divider-line"/>

    <!-- STAY DETAILS -->
    <div class="sec-title">Stay Details</div>
    <div class="dates-row">
      <div class="date-box">
        <div class="lbl">Check-In</div>
        <div class="date"><?=date('d M Y', strtotime($b['check_in']))?></div>
        <div class="day"><?=date('l', strtotime($b['check_in']))?></div>
      </div>
      <div class="dates-arrow">
        <span style="font-size:1.4rem">→</span>
        <div class="nights"><?=$nights?> Night<?=$nights>1?'s':''?></div>
      </div>
      <div class="date-box">
        <div class="lbl">Check-Out</div>
        <div class="date"><?=date('d M Y', strtotime($b['check_out']))?></div>
        <div class="day"><?=date('l', strtotime($b['check_out']))?></div>
      </div>
    </div>

    <div class="info-grid">
      <div class="irow"><div class="lbl">Room Type</div><div class="val"><?=e($b['room_type'])?></div></div>
      <div class="irow"><div class="lbl">Room Number</div><div class="val"><?=e($b['room_number'])?></div></div>
      <div class="irow"><div class="lbl">Number of Guests</div><div class="val"><?=e($b['guests'])?> Guest<?=$b['guests']>1?'s':''?></div></div>
      <div class="irow"><div class="lbl">Price Per Night</div><div class="val"><?=fmtCur($b['price_per_night'])?></div></div>
    </div>

    <!-- AMENITIES -->
    <?php if(!empty($amenitiesList)): ?>
    <div class="sec-title" style="margin-top:.5rem">Room Amenities</div>
    <div class="amenities-row">
      <?php foreach($amenitiesList as $a): ?>
      <span class="amenity-tag">✓ <?=e(trim($a))?></span>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <hr class="divider-line"/>

    <!-- PAYMENT SUMMARY -->
    <div class="sec-title">Payment Summary</div>
    <div>
      <span class="pay-badge" style="background:<?=$pc['bg']?>;color:<?=$pc['color']?>">
        💳 <?=$pc['label']?> — <?=ucwords(str_replace('_',' ',$b['payment_method']))?>
      </span>
    </div>
    <table class="price-table">
      <tr>
        <td><?=e($b['room_type'])?> × <?=$nights?> night<?=$nights>1?'s':''?></td>
        <td><?=fmtCur($b['price_per_night'])?>/night</td>
        <td><?=fmtCur($subtotal)?></td>
      </tr>
      <tr class="tax-row">
        <td>Tax &amp; Service Charge</td>
        <td>10%</td>
        <td><?=fmtCur($tax)?></td>
      </tr>
      <tr class="total-row">
        <td colspan="2">Total Amount</td>
        <td><?=fmtCur($total)?></td>
      </tr>
    </table>

    <!-- SPECIAL REQUESTS -->
    <?php if(!empty($b['special_requests'])): ?>
    <hr class="divider-line"/>
    <div class="sec-title">Special Requests</div>
    <div class="special-box">💬 <?=e($b['special_requests'])?></div>
    <?php endif; ?>

    <!-- POLICIES NOTE -->
    <div style="background:#f7f9f7;border-radius:8px;padding:1rem 1.2rem;font-size:.8rem;color:#666;line-height:1.8;margin-top:.5rem">
      <strong style="color:#1a1a2e">📋 Policies</strong><br>
      • Free cancellation up to 24 hours before check-in<br>
      • Check-in from 14:00 | Check-out by 12:00<br>
      • Valid ID required at check-in<br>
      • This receipt serves as confirmation of your booking
    </div>

  </div><!-- /.rec-body -->

  <!-- FOOTER -->
  <div class="rec-footer">
    <div>
      <div class="thank-you">Thank you for choosing HBMS Hotel!</div>
      <div class="help-text">Questions? Contact us at info@hbms.com or +233 20 000 0000</div>
    </div>
    <div class="barcode"><?=e($b['booking_ref'])?> · <?=date('Ymd', strtotime($b['created_at']))?></div>
  </div>

</div><!-- /.receipt -->
</div><!-- /.receipt-wrap -->

</body>
</html>
