-- ============================================================
--  HBMS Database  –  Run this FIRST in phpMyAdmin
--  FIX: Corrected password hashes to match documented passwords
-- ============================================================
CREATE DATABASE IF NOT EXISTS hbms_db
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE hbms_db;

-- USERS
CREATE TABLE IF NOT EXISTS users (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  name       VARCHAR(120) NOT NULL,
  email      VARCHAR(180) NOT NULL UNIQUE,
  password   VARCHAR(255) NOT NULL,
  phone      VARCHAR(25)  DEFAULT NULL,
  role       ENUM('admin','staff','guest') DEFAULT 'guest',
  status     ENUM('active','inactive') DEFAULT 'active',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- ROOM TYPES
CREATE TABLE IF NOT EXISTS room_types (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  name        VARCHAR(80)    NOT NULL,
  description TEXT,
  price       DECIMAL(10,2)  NOT NULL,
  capacity    INT            DEFAULT 2,
  size_sqm    DECIMAL(6,2)   DEFAULT 25,
  amenities   VARCHAR(500)   DEFAULT 'WiFi,AC,TV',
  image_url   VARCHAR(500)   DEFAULT ''
);

-- ROOMS
CREATE TABLE IF NOT EXISTS rooms (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  room_number VARCHAR(10)   NOT NULL UNIQUE,
  type_id     INT           NOT NULL,
  floor       INT           DEFAULT 1,
  status      ENUM('available','occupied','maintenance','reserved') DEFAULT 'available',
  FOREIGN KEY (type_id) REFERENCES room_types(id) ON DELETE CASCADE
);

-- BOOKINGS
CREATE TABLE IF NOT EXISTS bookings (
  id               INT AUTO_INCREMENT PRIMARY KEY,
  booking_ref      VARCHAR(20)   NOT NULL UNIQUE,
  user_id          INT           NOT NULL,
  room_id          INT           NOT NULL,
  check_in         DATE          NOT NULL,
  check_out        DATE          NOT NULL,
  guests           INT           DEFAULT 1,
  total_amount     DECIMAL(10,2) NOT NULL,
  status           ENUM('pending','confirmed','checked_in','checked_out','cancelled') DEFAULT 'pending',
  payment_status   ENUM('unpaid','paid','refunded') DEFAULT 'unpaid',
  payment_method   ENUM('card','cash','mobile_money','bank_transfer') DEFAULT 'card',
  special_requests TEXT,
  created_at       DATETIME      DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (room_id) REFERENCES rooms(id) ON DELETE CASCADE
);

-- CONTACT MESSAGES
CREATE TABLE IF NOT EXISTS contact_messages (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  name       VARCHAR(120) NOT NULL,
  email      VARCHAR(180) NOT NULL,
  subject    VARCHAR(255) DEFAULT '',
  message    TEXT         NOT NULL,
  is_read    TINYINT(1)   DEFAULT 0,
  created_at DATETIME     DEFAULT CURRENT_TIMESTAMP
);

-- REVIEWS
CREATE TABLE IF NOT EXISTS reviews (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  user_id    INT       NOT NULL,
  booking_id INT       DEFAULT NULL,
  rating     TINYINT   NOT NULL CHECK (rating BETWEEN 1 AND 5),
  comment    TEXT,
  approved   TINYINT(1) DEFAULT 0,
  created_at DATETIME  DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ============================================================
--  SEED DATA
-- ============================================================
-- Login credentials:
--   admin@hbms.com   →  Admin@1234  (role: admin)
--   staff@hbms.com   →  Admin@1234  (role: staff)
--   guest@hbms.com   →  Guest@1234  (role: guest)
--
-- BUG FIXED: Original file used Laravel's placeholder hash for
-- "password" instead of the documented "Admin@1234" password.
-- All hashes below are freshly generated with bcrypt cost=12.
-- ============================================================

INSERT IGNORE INTO users (name, email, password, role) VALUES
('Super Admin',  'admin@hbms.com', '$2y$12$BZkWPj5ww1AxXpWYFAgNkeceXNgww6101tr0GHqJstAiAsj8T02zO', 'admin'),
('Staff Member', 'staff@hbms.com', '$2y$12$BZkWPj5ww1AxXpWYFAgNkeceXNgww6101tr0GHqJstAiAsj8T02zO', 'staff'),
('John Guest',   'guest@hbms.com', '$2y$12$JuoDE/o4jx.RdwWtkvkxeuiDucql/6iuuf9TRaNz6qNgnp3tnCR/a', 'guest');

INSERT IGNORE INTO room_types (name, description, price, capacity, size_sqm, amenities, image_url) VALUES
('Standard Room',  'Comfortable room with all basic amenities for a pleasant stay.',           89,  2, 25, 'WiFi,AC,TV,En-suite',                 'https://images.unsplash.com/photo-1631049307264-da0ec9d70304?w=800'),
('Deluxe Room',    'Spacious deluxe room with premium furnishings and city view.',            129,  2, 35, 'WiFi,AC,TV,Mini-bar,Balcony',         'https://images.unsplash.com/photo-1618773928121-c32242e63f39?w=800'),
('Executive Suite','Luxury suite with separate living area, kitchenette and panoramic view.',249,  4, 60, 'WiFi,AC,TV,Kitchen,Jacuzzi,Lounge',   'https://images.unsplash.com/photo-1611892440504-42a792e24d32?w=800'),
('Family Room',    'Large room designed for families with extra beds and kids amenities.',    159,  5, 50, 'WiFi,AC,TV,2 Beds,Kids Corner',       'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?w=800'),
('Dormitory Bed',  'Budget-friendly shared dormitory with secure lockers and bunk beds.',     25,  1,  8, 'WiFi,Locker,Shared Bath,Reading Light','https://images.unsplash.com/photo-1590490360182-c33d57733427?w=800');

INSERT IGNORE INTO rooms (room_number, type_id, floor, status) VALUES
('101',1,1,'available'),('102',1,1,'available'),('103',1,1,'available'),
('201',2,2,'available'),('202',2,2,'available'),
('301',3,3,'available'),
('401',4,4,'available'),
('D01',5,0,'available'),('D02',5,0,'available'),('D03',5,0,'available');

INSERT IGNORE INTO reviews (user_id, rating, comment, approved) VALUES
(3, 5, 'Absolutely wonderful experience. Staff was attentive, rooms spotless. Will return!', 1),
(3, 4, 'Great facilities and very friendly staff. The Wi-Fi was fast and breakfast excellent.', 1);
