<?php
// Call: include_header('Page Title', 'active-nav-key');
function include_header(string $title, string $activeNav = ''): void {
    $base = BASE_URL;
    $flash = getFlash();
    $flashHtml = '';
    if ($flash) {
        $cls = $flash['type'] === 'success' ? 'flash-success' : 'flash-error';
        $flashHtml = '<div class="flash '.$cls.'"><i class="fas fa-'.($flash['type']==='success'?'check-circle':'exclamation-circle').'"></i> '.e($flash['msg']).'</div>';
    }
    $nav = [
        'home'       => ['Home',       $base.'index.php'],
        'about'      => ['About',      $base.'pages/about.php'],
        'facilities' => ['Facilities', $base.'pages/facilities.php'],
        'rooms'      => ['Rooms',      $base.'pages/rooms.php'],
        'gallery'    => ['Gallery',    $base.'pages/gallery.php'],
        'contact'    => ['Contact',    $base.'pages/contact.php'],
    ];
    $navLinks = '';
    foreach ($nav as $key => [$label, $href]) {
        $cls = $key === $activeNav ? ' class="active"' : '';
        $navLinks .= "<li><a href=\"$href\"$cls>$label</a></li>";
    }
    $authLinks = isLoggedIn()
        ? '<li><a href="'.($base).'pages/dashboard.php" class="btn-nav"><i class="fas fa-user"></i> Dashboard</a></li>
           <li><a href="'.$base.'php/auth.php?action=logout" class="btn-nav btn-nav-outline">Logout</a></li>'
        : '<li><a href="'.$base.'pages/login.php" class="btn-nav">Sign In</a></li>
           <li><a href="'.$base.'pages/register.php" class="btn-nav btn-nav-outline">Register</a></li>';
    echo <<<HTML
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<title>$title – HBMS</title>
<link rel="stylesheet" href="{$base}css/style.css"/>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700&family=Jost:wght@300;400;500;600&display=swap" rel="stylesheet"/>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>
</head>
<body>
<nav class="navbar" id="navbar">
  <div class="nav-container">
    <a href="{$base}index.php" class="nav-logo"><span>H</span>BMS</a>
    <ul class="nav-links" id="navLinks">
      $navLinks
      $authLinks
    </ul>
    <div class="hamburger" id="hamburger"><span></span><span></span><span></span></div>
  </div>
</nav>
$flashHtml
HTML;
}

function include_footer(): void {
    $base = BASE_URL;
    echo <<<HTML
<footer class="footer">
  <div class="container footer-grid">
    <div class="footer-col">
      <div class="footer-logo"><span>H</span>BMS</div>
      <p>A modern hotel &amp; hostel management system built for efficiency, comfort, and excellence.</p>
      <div class="social-links">
        <a href="#"><i class="fab fa-facebook-f"></i></a>
        <a href="#"><i class="fab fa-twitter"></i></a>
        <a href="#"><i class="fab fa-instagram"></i></a>
        <a href="#"><i class="fab fa-linkedin-in"></i></a>
      </div>
    </div>
    <div class="footer-col">
      <h4>Quick Links</h4>
      <ul>
        <li><a href="{$base}index.php">Home</a></li>
        <li><a href="{$base}pages/about.php">About Us</a></li>
        <li><a href="{$base}pages/rooms.php">Rooms</a></li>
        <li><a href="{$base}pages/facilities.php">Facilities</a></li>
        <li><a href="{$base}pages/contact.php">Contact</a></li>
      </ul>
    </div>
    <div class="footer-col">
      <h4>Services</h4>
      <ul>
        <li><a href="{$base}pages/booking.php">Online Booking</a></li>
        <li><a href="{$base}pages/rooms.php">Room Listing</a></li>
        <li><a href="{$base}pages/facilities.php">Facilities</a></li>
        <li><a href="{$base}pages/contact.php">Guest Support</a></li>
      </ul>
    </div>
    <div class="footer-col">
      <h4>Contact</h4>
      <p><i class="fas fa-map-marker-alt" style="color:#27ae60"></i> 21 Liberty Street, Accra, Ghana</p>
      <p><i class="fas fa-phone-alt" style="color:#27ae60"></i> +233 30 222 5555</p>
      <p><i class="fas fa-envelope" style="color:#27ae60"></i> info@hbms.com</p>
    </div>
  </div>
  <div class="footer-bottom">
    <p>&copy; 2025 HBMS &ndash; Hotel &amp; Hostel Management System. All Rights Reserved.</p>
  </div>
</footer>
<script src="{$base}js/main.js"></script>
</body>
</html>
HTML;
}
