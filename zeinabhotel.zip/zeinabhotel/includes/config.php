<?php
// ─── Database ───────────────────────────────────────────────
define('DB_HOST',    'localhost');
define('DB_USER',    'root');
define('DB_PASS',    '');
define('DB_NAME',    'hbms_db');
define('DB_CHARSET', 'utf8mb4');

// ─── Site ────────────────────────────────────────────────────
define('SITE_NAME', 'HBMS');
define('BASE_URL',  'http://ozhms.wuaze.com/');
define('CURRENCY',  '$');
define('ADMIN_EMAIL','naamakonko@gmail.com');

// ─── Session ─────────────────────────────────────────────────
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params(['httponly'=>true,'samesite'=>'Lax']);
    session_start();
}

// ─── PDO Connection ──────────────────────────────────────────
try {
    $pdo = new PDO(
        "mysql:host=".DB_HOST.";dbname=".DB_NAME.";charset=".DB_CHARSET,
        DB_USER, DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]
    );
} catch (PDOException $e) {
    // Show friendly error instead of crashing
    die('
    <style>body{font-family:sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;background:#f0f2f5;}
    .box{background:#fff;padding:2rem 3rem;border-radius:12px;box-shadow:0 4px 20px rgba(0,0,0,.1);text-align:center;max-width:500px}
    h2{color:#e74c3c}p{color:#666}code{background:#f5f5f5;padding:.2rem .5rem;border-radius:4px;font-size:.9rem}</style>
    <div class="box">
      <h2>⚠ Database Connection Failed</h2>
      <p>Could not connect to MySQL. Please check your settings in <code>includes/config.php</code>.</p>
      <p><strong>Error:</strong> '.htmlspecialchars($e->getMessage()).'</p>
      <p>Make sure MySQL is running and the database <code>'.DB_NAME.'</code> exists.<br>
      Run <code>includes/database.sql</code> in phpMyAdmin first.</p>
    </div>');
}

// ─── Helpers ─────────────────────────────────────────────────
function e(string $v): string { return htmlspecialchars($v, ENT_QUOTES, 'UTF-8'); }
function sanitize(string $v): string { return trim(strip_tags($v)); }
function redirect(string $url): void { header("Location: $url"); exit(); }
function isLoggedIn(): bool { return !empty($_SESSION['user_id']); }
function isAdmin(): bool { return isLoggedIn() && in_array($_SESSION['role'],['admin','staff']); }
function requireLogin(): void { if(!isLoggedIn()) { flash('error','Please sign in first.'); redirect(BASE_URL.'pages/login.php'); } }
function requireAdmin(): void { if(!isAdmin()) { flash('error','Access denied.'); redirect(BASE_URL.'pages/login.php'); } }
function flash(string $type, string $msg): void { $_SESSION['flash'] = ['type'=>$type,'msg'=>$msg]; }
function getFlash(): ?array { $f=$_SESSION['flash']??null; unset($_SESSION['flash']); return $f; }
function fmtDate(string $d): string { return date('M d, Y', strtotime($d)); }
function fmtCur(float $a): string { return CURRENCY.number_format($a,2); }
function bookingRef(): string { return 'HBMS-'.strtoupper(substr(md5(uniqid(mt_rand(),true)),0,8)); }
function nights(string $ci, string $co): int { $d=(new DateTime($ci))->diff(new DateTime($co))->days; return max(1,$d); }
