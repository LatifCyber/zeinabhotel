<?php
function admin_header(string $title, string $activeNav = ''): void {
    $base = BASE_URL;
    $flash = getFlash();
    $flashHtml='';
    if($flash){$cls=$flash['type']==='success'?'success':'error';$flashHtml='<div class="d-flash '.$cls.'">'.e($flash['msg']).'</div>';}
    $unreadMsgs = $GLOBALS['pdo']->query("SELECT COUNT(*) FROM contact_messages WHERE is_read=0")->fetchColumn();
    $pendingBks = $GLOBALS['pdo']->query("SELECT COUNT(*) FROM bookings WHERE status='pending'")->fetchColumn();
    $nav=[
        ['dashboard.php','fa-th-large','Dashboard',''],
        ['bookings.php', 'fa-calendar-check','Bookings',$pendingBks],
        ['rooms.php',    'fa-bed','Rooms',''],
        ['guests.php',   'fa-users','Guests',''],
        ['messages.php', 'fa-envelope','Messages',$unreadMsgs],
        ['settings.php', 'fa-cog','Settings',''],
    ];
    $adminPath = $base.'pages/admin/';
    $navHtml='';
    foreach($nav as [$file,$icon,$label,$badge]) {
        $active = (basename($_SERVER['PHP_SELF'])===$file) ? 'active' : '';
        $badgeHtml = $badge ? '<span class="badge-pill">'.$badge.'</span>' : '';
        $navHtml .= "<div class=\"nav-item\"><a href=\"{$adminPath}{$file}\" class=\"$active\"><i class=\"fas $icon\"></i> $label $badgeHtml</a></div>";
    }
    $uname = e($_SESSION['user_name']??'Admin');
    $uinit = strtoupper(substr($uname,0,2));
    echo <<<HTML
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<title>$title – HBMS Admin</title>
<link rel="stylesheet" href="{$base}css/style.css"/>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&family=Jost:wght@300;400;500;600&display=swap" rel="stylesheet"/>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>
</head>
<body>
<div class="dash-layout">
<aside class="dash-sidebar">
  <div class="dash-logo"><a href="{$base}index.php" style="color:inherit"><span>H</span>BMS</a></div>
  <div class="dash-user-box">
    <div class="d-avatar">$uinit</div>
    <div class="d-avatar-name"><strong>$uname</strong><small>Administrator</small></div>
  </div>
  <nav class="dash-nav">
    <div class="nav-section">Main Menu</div>
    $navHtml
    <div class="nav-section">Site</div>
    <div class="nav-item"><a href="{$base}index.php" target="_blank"><i class="fas fa-external-link-alt"></i> View Site</a></div>
    <div class="nav-item"><a href="{$base}php/auth.php?action=logout"><i class="fas fa-sign-out-alt"></i> Sign Out</a></div>
  </nav>
</aside>
<div class="dash-main">
<div class="dash-topbar">
  <h1>$title</h1>
  <span style="font-size:.83rem;color:#888"><?=date('D, M j Y')?></span>
</div>
<div class="dash-content">
$flashHtml
HTML;
}

function admin_footer(): void {
    echo "</div></div></div>\n<script src=\"".BASE_URL."js/main.js\"></script>\n</body></html>";
}
